<?php echo $default_assets; ?>

<link href="<?php echo base_url();?>assets/admin/css/fixed-data-table.css" rel="stylesheet">

</head>
<?php echo $sidebar; ?>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <div type="button" class="btn" data-toggle="popover" data-placement="right" title="" data-content="This is the name that will be shown on invoices, bills created for this contact."><i class="fa fa-info-circle" aria-hidden="true"></i></div>
                </h3>
            </div>
            <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for...">
                <span class="input-group-btn">
                <button class="btn btn-default" type="button">Go!</button>
                </span> </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Pool Stages <small></small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a> </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="">
                            <table id="example" class="display" cellspacing="0" width="100%">
                                <thead>
                                <tr class="tablbg">
                                    <th>No</th>
                                    <th>Stage Name</th>
                                    <th>Description</th>
                                    <th>Created On</th>
                                    <th></th>


                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>No</th>
                                    <th>Stage Name</th>
                                    <th>Description</th>
                                    <th>Created On</th>
                                    <th></th>

                                </tr>
                                </tfoot>
                                <tbody style=" height:100px;overflow:scroll">
                                <?php foreach($all_stages as $key=>$stages){?>
                                <tr><input type="hidden" value="<?php echo $stages['id'];?>" class="hiddentype_id">
                                    <td class="titleclass"><?php echo $key+1?></td>
                                    <td class="titleclass"><?php echo $stages['stage_name'];?></td>
                                    <td class="description"> <?php echo $stages['description'];?></td>
                                    <td class="createdon"><?php echo $stages['created_on'];?></td>
                                    <td><button type="button" class="type_sub" class="btn btn-primary type_sub" data-toggle="modal" data-target="#agree1">Edit </button>
                                        <button type="button" class="btn btn-danger commission_delete">Delete </button></td>

                                </tr>
                                    <?php }?>
                                <div id="agree1" class="modal fade" role="dialog">
                                    <div class="modal-dialog">

                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">X</button>
                                                <h4 class="modal-title">Edit Pool Stages</h4>
                                            </div>
                                            <div class="modal-body">
                                                <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
                                                    <div class="panel">
                                                        <!--                            <a class="panel-heading collapsed" role="tab" id="headingOne" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">-->
                                                        <!--                                <h4 class="panel-title"></h4>-->
                                                        <!--                            </a>-->

                                                    </div>
                                                    <form method="post" id="commission_forms" class="commission_forms" name="commission_forms">
                                                        <div class="col-md-10 col-sm-12 col-xs-12">
                                                            <label>Pool Name</label>
                                                            <input type="hidden" placeholder="Last Name" class="form-control" id="hiddentype" name="hiddentype">
                                                            <select id="channel_type" class="form-control validate[required]" name="channel_type">
                                                                <?php foreach($partner_type['type'] as $type){?>
                                                                <option value="<?php echo $type['conid'];?>"><?php echo $type['title'];?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-10 col-sm-12 col-xs-12">
                                                            <label>Company Commission</label>
                                                            <input type="text" placeholder="Company Commission" class="form-control validate[required]" id="company_commi" name="company_commi">
                                                        </div>
                                                        <div class="col-md-10 col-sm-12 col-xs-12">
                                                            <label>Direcy Commission</label>
                                                            <input type="text" placeholder="Direct Commission" class="form-control validate[required]" id="direct_commi" name="direct_commi">
                                                        </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-primary editsub" id="editsub">Submit</button>
                                            </div>
                                            </form>
                                        </div>



                                    </div>
                                </div>
                                <script>
                                    $(document).ready(function(){
                                        $(document).on('click','.type_sub',function(){
                                            var cur=$(this);
                                            var hiddentype_id=cur.parent().parent().find('.hiddentype_id').val();
                                            var title=cur.parent().parent().find('.titleclass').text();
                                            var direct=cur.parent().parent().find('.direct_commi').text();
                                            var pooling=cur.parent().parent().find('.pooling_commi').text();
                                            $(document).find('#title').val(title);
                                            $(document).find('#company_commi').val(pooling);
                                            $(document).find('#direct_commi').val(direct);
                                            $(document).find('#hiddentype').val(hiddentype_id);

                                        });
                                        $("#editsub").click(function(e){
                                            e.preventDefault();
                                            var str = $("#commission_forms").validationEngine("validate");
                                            if(str==true){

                                                var data=$("#commission_forms").serializeArray();
                                                $('.body_blur').show();
                                                $.post("<?php echo base_url();?>admin/pooling/edit_pooling_byid", data, function(data){
                                                    $('.body_blur').hide();
                                                    if(data.status){
                                                        noty({text:"Successfully updated",type: 'success',layout: 'top', timeout: 3000});
                                                        $('#commission_forms')[0].reset();
                                                        window.location="<?php echo base_url();?>channel_pooling";
                                                    }
                                                    else{
                                                        noty({text:data.reason,type: 'error',layout: 'top', timeout: 3000});
                                                        $('#commission_forms')[0].reset();
                                                    }
                                                },'json');
                                            }
                                            else{

                                            }

                                        })
                                        $(document).on('click','.commission_delete',function(){
                                            var cur=$(this);
                                            var hiddentypeid=cur.parent().parent().find('.hiddentype_id').val();
                                            noty({
                                                text: 'Do you want to continue?',
                                                type: 'warning',
                                                buttons: [
                                                    {addClass: 'btn btn-primary', text: 'Ok', onClick: function($noty) {

                                                        // this = button element
                                                        // $noty = $noty element

                                                        $noty.close();
                                                        $('.body_blur').show();
                                                        $.post('<?php echo base_url();?>admin/Pooling/delete_commissionbyid/'+hiddentypeid, function(data){
                                                            $('.body_blur').hide();
                                                            if(data.status){
                                                                noty({text: 'Deleted Succesfully', type: 'success', timeout:1000});
                                                                cur.parent().parent().remove();
                                                            }else{
                                                                noty({text: 'Database Error', type: 'error'});
                                                            }
                                                        },'json');
                                                    }
                                                    },
                                                    {addClass: 'btn btn-danger', text: 'Cancel', onClick: function($noty) {
                                                        $noty.close();

                                                    }
                                                    }
                                                ]
                                            });

                                        })
                                    });
                                </script>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>

    <!--************************row  end******************************************************************* -->




</div>

<?php echo $footer; ?>
<script src="<?php echo base_url();?>assets/admin/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/admin/js/dataTables.fixedHeader.min.js" type="text/javascript"></script>


<script>

    $(document).ready(function() {
        var table = $('#example').DataTable( {
            fixedHeader: {
                header: true,
                footer: true,

            }
        } );

    } );

</script>


<!-- Datatables -->

<!--============new customer popup start here=================-->

</body>
</html>
