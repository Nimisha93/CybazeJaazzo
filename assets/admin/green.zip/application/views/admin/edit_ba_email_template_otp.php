<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

</head>

<body style="background-color:#f2f2f2;margin:0;padding:0;font-family:Arial;color:#999;">
	<div id="main_body" style="width: 60%;padding: 0px 0px 60px 0px;background-color: #fff;float: left;margin: 2% 20%;">
		
		
         
         
         
        <div class="scnd_main" style="font-size: 13px;
    padding: 1px 20px; width: 78%; margin: 70px 70px 0px;line-height: 17px;border-top: 0;clear: both;background-color: #f2f2f2;">
        	<div class="log_box" style="padding: 0px 0px 0px 34%;float:left;">
            	<img src="<?php echo base_url(); ?>assets/admin/images/online-portal-logo.png" style="margin:17px 0px;" />
            </div>
            <div class="txt_box" style="background: #fff;
    color: #5b5b5b;
    border-radius: 4px;
    font-family: arial;
    font-size: 13px;
    padding: 5px 20px 15px 20px;
    width: 90%;
    margin: 20px auto;
    line-height: 20px;
    border: 1px #ddd solid;
    border-top: 3px solid #06306c;
    clear: both;">
            	<h2 style=" text-align: center;">Thanks for choosing Greenindia</h2>
            	<p>Hi Shabas</p>
                <p>You just joined the team greenindia . Here are a few details of the team.</p>
                <p>User Name :<span class="bld" style="font-weight:600;color:#000">  <?php echo $email ?></span></p>
               	<p>Password :<span class="bld" style="font-weight:600;color:#000"> <?php echo $password ?></span></p>
                <p>Please contact us at <a href="#">support@greenindia.com </a>for any help.</p>
                
                <div class="social_media" style="padding: 5px 0px 0px 32%;">
                	<div class="fb" style="height:40px;width:40px;border-radius:100%;display: -webkit-inline-box;margin:0px 5px;">
                    	<a href="#"><img src="<?php echo base_url(); ?>assets/admin/images/fb.png" height="40px" /></a>
                    </div>
                    <div class="fb" style="height:40px;width:40px;border-radius:100%;display: -webkit-inline-box;margin:0px 5px;">
                    	<a href="#"><img src="<?php echo base_url(); ?>assets/admin/images/twtr.png" height="40px" /></a>
                    </div>
                    <div class="fb" style="height:40px;width:40px;border-radius:100%;display: -webkit-inline-box;margin:0px 5px;">
                    	<a href="#"><img src="<?php echo base_url(); ?>assets/admin/images/gpls.png" height="40px" /></a>
                    </div>
                </div>
            </div>
        	<div class="txt_box color" style="background-color:#06306c;
    padding: 1px 20px;">
            	<p style="color:#fff;
	text-align:center;">www.greenindia.com</p>
            </div>
        
        
        
        
        </div>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        














	</div>
</body>
</html>
