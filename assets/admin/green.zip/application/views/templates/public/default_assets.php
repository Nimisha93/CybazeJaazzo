


<link href="<?= base_url();?>assets/public/css/su-stylesheet.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url();?>assets/public/css/su-stylesheet2.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url();?>assets/public/css/su-bootstrap.css" rel="stylesheet" type="text/css" />
<!--<link rel="stylesheet" href="<?= base_url();?>assets/public/css/animate.min.css">-->
<link rel="stylesheet" href="<?= base_url();?>assets/public/css/font-awesome.min.css">
<!--===========common css end here ========================-->


<link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/public/css/ddmenu.css" />
 <link rel="stylesheet" href="<?php echo base_url();?>assets/public/validation/css/validationEngine.jquery.css" type="text/css"/>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/public/validation/css/template.css" type="text/css"/>
 <link rel="stylesheet" href="<?php echo base_url();?>assets/public/css/custom_style.css" type="text/css"/>

