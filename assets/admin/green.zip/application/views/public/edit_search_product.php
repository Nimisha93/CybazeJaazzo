    <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta mame="description" content=" " />
<META content="ALL" name="ROBOTS"/>
<META content="FOLLOW" name="ROBOTS"/>
<META content="" name="copyright"/>
<meta name="distribution" content="Global" />
<title>Greenindia</title>
<link rel="shortcut icon" href="<?= base_url();?>assets/public/favicon/favicon.png">
<?= $default_assets;?>

 <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/public/css/slick.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/public/css/slick-theme.css">





<style type="text/css">

.row{margin:0;}
@media (max-width:767px){

  .goToTop {
  position: static;
  top: 0;
  left: 0;
  height: 210px;
  z-index: 10;
}
.row{margin:0;}
}


</style>






<style>
.row{margin-left:0; margin-right:0;}

.goToTop{height:50px;position:fixed;background-color:#fff;border-bottom:1px solid #000}
@media (max-width:1000px){

.goToTop{height:auto;position:relative;background-color:#fff;}


}

</style>
</head>

<body>

<!--===========header end here ========================-->


  <?= $header;?>







<div class="clear"></div>

<!--===========main end here ========================-->
<main>


  <!--===========section end here ========================-->


    <!--===========section end here ========================-->
  <div class="clear"></div>



  <div class="bgclr6">
  <div class="container-fluid ">
 <div class="col-md-3 col-sm-3 hidtab">
 <div class="su_box95_marauoto border_right1 bgclr2 top_pad50">
 <div class="deal_ctgry">
<h3> Categories</h3>
 <ul>
 <li><a href="">Hot Deals</a></li>
 <li><a href="">Mobile Deals</a></li>
 <li><a href="">Crazy Deals</a></li>
 <li><a href="">Hot Deals</a></li>
 <li><a href="">Mobile Deals</a></li>
 <li><a href="">Crazy Deals</a></li>
 <li><a href="">Hot Deals</a></li>
 <li><a href="">Mobile Deals</a></li>
 <li><a href="">Crazy Deals</a></li>
 </ul>
 </div>
 </div>
 </div>

 <div class="dropdown drp8">
              <button class="dropbtn"><i class="fa fa-sort" aria-hidden="true"></i><span class="pd1">CATEGORIES:</span></button>
              <div class="dropdown-content">
              <a href="#">Hot Deals</a>
              <a href="#">Mobile Deals</a>
              <a href="#">Crazy Deals</a>
              <a href="#">Hot Deals</a>
              <a href="#">Mobile Deals</a>
              <a href="#">Crazy Deals</a>

              </div>
            </div>
     <!--===========col-md-3 end here ========================-->
 <div class="col-md-9 col-sm-12 col-xs-12 bgclr7 top_pad50">

 <h2 class="text-left">Hot Deals</h2>
 <div class="line2 bm_mar10"></div>

<?php foreach($results as $row) { ?>

 <div class="blk tp_mar20">
    <div class="deal"> <img src="<?php echo base_url();?>assets/admin\products/<?php echo $row['image'];?>" class="indxprct">

        <a href="<?= base_url();?>search/get_product_details/<?php echo $row['id'];?>">
        <div class="redmr2">Get this deal</div>
        </a>
        <div class="su_box100 dealbg1">
        <h4><img src="<?= base_url();?>assets/public/images/home/bismi.png" class="logoleft">Deal with Bismi  </h4>
        </div>

        <h3>aa  </h3>
        <div class="clear"></div>
        <div class="">
          <div class="su3bx">
            <div class="oldrate1"><span class="rupee">RS</span> <?php echo $row['actual_cost'];?> </div>
          </div>
          <div class="su3bx">
            <div class="offferrate1"><span class="rupee">RS</span> <?php echo $row['cost'];?> </div>
          </div>

          <div class="su3bx">
            <div class="offferrate3">- 69% </div>
          </div>

        </div>

        <div class="clear"></div>
      </div>

    </div>

  <?php } ?>

 </div>
      <!--===========col-md-9 end here ========================-->


 </div></div>





</main>
<?php echo $footer; ?>
<!-- <script src="<?= base_url();?>assets/public/js/cbpHorizontalMenu.min.js"></script>
<script>
      $(function() {
        cbpHorizontalMenu.init();
      });
    </script> -->


<!--=======================================slider right==============================================-->

<script src="<?= base_url();?>assets/public/js/slick.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    $(document).on('ready', function() {
    /*  $(".regular").slick({
        dots: true,
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 4,
      });*/
      $(".center").slick({
        dots: true,
        infinite: true,
        centerMode: true,
        slidesToShow: 3,
        slidesToScroll: 3
      });
      $(".variable").slick({
        dots: true,
        infinite: true,
        variableWidth: true,
    slidesToShow: 1,
        slidesToScroll: 1,
      });
    });


  </script>

  <script>

  $(document).on('ready', function() {
 $('.regular').slick({
  dots: true,
  loop: true,
  speed: 300,
  slidesToShow: 5,
  slidesToScroll: 4,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 800,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 580,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
 });

</script>


<script>

  $(document).on('ready', function() {
 $('.regular2').slick({
  dots: true,
  loop: true,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 800,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 580,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
 });

</script>


<script type="text/javascript">
    // <![CDATA[
    $(document).ready(function() {
        $(".gototop").click(function() {
            $("html, body").animate({"scrollTop": "0px"});
        });
    });
</script>

</body>
</html>