<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="background:url(bg.jpg) repeat;">	<tbody>
<tr>
    <td align="center" valign="top">
        <table cellpadding="0" cellspacing="0" align="center" bgcolor="#ffffff" style=" background:#FFFFFF; border:1px solid #e3e3e3; border-radius: 3px; max-width:582px">
            <tbody>
            <tr>
                <td width="580" align="center" style="padding:5px;">
                    <table border="0" cellpadding="0" cellspacing="0" align="center" style="max-width:570px;">
                        <tbody>
                        <tr>
                            <td align="center" valign="top">
                                <a href="http://greenindia.in/" style="display:block;">
                                    <div style="width:100%"><img src="<?= base_url();?>assets/superadmin/dist/img/.JPG" border="0" alt="" style="margin:0; display:block; max-width:570px; width:inherit" vspace="0" hspace="0" align="absmiddle">
                                    </div>
                                </a>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td width="580" align="center" style="padding:15px;"> <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="max-width:540px;">
                    <tbody>
                    <tr bgcolor="#ffffff">
                        <td width="540" align="left" style="font-size:14px; color:#333333; font-family: '.'Open Sans'.', Gill Sans, Arial, Helvetica, sans-serif;">Dear Customer,
                            <br><br> We’re proud to annly change the way you hire. Exciting, isn’t it?<br><br>Your Bill details are given in the pdf attached with.

                        </td>
                    </tr>
                    </tbody>
                </table></td>
            </tr>


            <tr>
                <td width="580" align="center" style="padding:15px;"><table border="0" cellpadding="0" cellspacing="0" align="center" style="max-width:550px;">
                    <tbody>
                    <tr>
                        <td width="550" style=" font-weight:bold;  font-size:15px; padding:5px 0px; font-family: '.'Open Sans'.', Gill Sans, Arial, Helvetica, sans-serif; text-align:left; "><a href="" style=" color:#0082c8; text-decoration:none;">Your User Details </a></td>
                    </tr>
                    <tr>
                        <td width="550" style=" color:#333333; font-size:12px;  font-family: "Open Sans", Gill Sans, Arial, Helvetica, sans-serif; padding:5px 0px;">
                        Username : <?= $email;?>/<?= $mobile;?>
                        </td>
                        <td width="550" style=" color:#333333; font-size:12px;  font-family: "Open Sans", Gill Sans, Arial, Helvetica, sans-serif; padding:5px 0px;">
                        OTP : <?= $psw;?>
                        </td>
                    </tr>

                    </tbody></table></td>
            </tr>


            <tr>
                <td width="580" align="center" style="padding:15px;"> <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="max-width:550px;">
                    <tbody>
                    <tr bgcolor="#ffffff">
                        <td width="540" align="left" style=" font-size:14px; color:#333333; font-family: '.'Open Sans'.', Gill Sans, Arial, Helvetica, sans-serif;">If you’ve got any questions for us, drop us a note at <a href="mailto:info@greenindia.in" style="  color:#008BCF; text-decoration:none;" target="_blank">info@greenindia.in</a>. or call us on <a style="color:#008bcf; text-decoration:none;" href="tel:+91-9946259099">+91-9349208864</a>(Mon to Sat, 9 am to 6 pm). <br><br>Name<br>
                            Team Green India Team</td>
                    </tr>
                    <tr>
                        <td height="20"></td>
                    </tr>
                    <tr>
                        <td align="center" style="font-size:11px; font-family: Helvetica,Arial,sans-serif;"><p style="margin:0;padding:3px 0 0px; font-size:11px; font-family: Helvetica,Arial,sans-serif; line-height:13px;">You are receiving this mail from Green India.  </p>
                            <p style="margin:0;padding:3px 0 3px; font-size:11px; font-family: Helvetica,Arial,sans-serif;  line-height:13px;">For any assistance, visit our <a href="http://greenindia.in/" style=" font-size:11px; font-family: Helvetica,Arial,sans-serif; color:#008BCF;text-decoration:none;" target="_blank">Help center</a> or write to us at <a href="mailto:info@greenindia.in" style=" font-size:11px; font-family: Helvetica,Arial,sans-serif; color:#008BCF;text-decoration:none;" target="_blank">info@greenindia.in</a></p></td>
                    </tr>
                    <tr>
                        <td align="center" style=" line-height:13px; font-size:11px; font-family: Helvetica,Arial,sans-serif; color:#008BCF; padding-bottom:10px;">  <a href="http://greenindia.in/" target="_blank" style="color:#0082c8; text-decoration:none;">greenindia.in/</a>
                        </td>
                    </tr>
                    </tbody>
                </table></td>
            </tr>

            </tbody>

        </table>





    </td>
</tr>
</tbody></table>