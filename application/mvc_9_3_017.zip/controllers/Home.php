<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
/**
* 
*/
class Home extends CI_controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model(array('user/user_model'));
		//$this->load->helper('url');
		$this->load->library(array('form_validation'));

		$this->load->helper(array('form', 'date'));
	}
	function index()
	{
	//	$this->load->library('session');
		$session_array = $this->session->userdata('logged_in_user');
		if(isset($session_array)){
			$login_id = $session_array['id'];
			$data['wallet'] = $this->user_model->get_wallete_values_user($login_id);
			$data['channel_partner'] = $this->user_model->get_channel_partner();	
				
		}

		$data['default_assets'] = $this->load->view('templates/public/default_assets','',TRUE);
		$data["header"] = $this->load->view("templates/public/public_header",$data,TRUE);
		$data['footer'] = $this->load->view('templates/public/public_footer','',TRUE);
		$this->load->view("public/edit_landing_page",$data);
	}
	function show_deals()
	{
		$session_array = $this->session->userdata('logged_in_user');
		if(isset($session_array)){
			$login_id = $session_array['id'];
			$data['wallet'] = $this->user_model->get_wallete_values_user($login_id);
			$data['channel_partner'] = $this->user_model->get_channel_partner();	
				
		}

		$data['default_assets'] = $this->load->view('templates/public/default_assets','',TRUE);
		$data["header"] = $this->load->view("templates/public/public_header",$data,TRUE);
		$data['footer'] = $this->load->view('templates/public/public_footer','',TRUE);
		$this->load->view("public/edit_show_deals",$data);
	}
	function product_details()
	{
		$session_array = $this->session->userdata('logged_in_user');
		if(isset($session_array)){
			$login_id = $session_array['id'];
			$data['wallet'] = $this->user_model->get_wallete_values_user($login_id);
			$data['channel_partner'] = $this->user_model->get_channel_partner();	
				
		}

		$data['default_assets'] = $this->load->view('templates/public/default_assets','',TRUE);
		$data["header"] = $this->load->view("templates/public/public_header",$data,TRUE);
		$data['footer'] = $this->load->view('templates/public/public_footer','',TRUE);
		$this->load->view("public/edit_show_product_details",$data);
	}
	function club_membership()
	{
		$session_array = $this->session->userdata('logged_in_user');
		if(isset($session_array)){
			$login_id = $session_array['id'];
			$data['wallet'] = $this->user_model->get_wallete_values_user($login_id);
			$data['channel_partner'] = $this->user_model->get_channel_partner();	
				
		}

		$data['default_assets'] = $this->load->view('templates/public/default_assets','',TRUE);
		$data["header"] = $this->load->view("templates/public/public_header",$data,TRUE);
		$data['footer'] = $this->load->view('templates/public/public_footer','',TRUE);
		$this->load->view("public/edit_club_member_details",$data);
	}
}

?>