<?php
Class Channelpartner_model extends CI_Model{

    function __construct(){
        parent:: __construct();
        $this->load->database();
    }

    function add_partnertype(){

        $this->db->trans_begin();
        $data=array(
            'title'=>$this->input->post('title'),
            'description'=>$this->input->post('description')
        );
        $this->db->insert('gp_pl_channel_partner_types',$data);
        if($this->db->trans_status=false){
            $this->db->trans_rollback();
            return false;
        }
        else{
            $this->db->trans_commit();
            return true;
        }
    }

    function get_partner_type(){
        $qry="select ct.id,ct.title from gp_pl_channel_partner_types ct where ct.is_del='0' order by ct.id desc";
        $qry=$this->db->query($qry);
        if($qry){
            $data['type']=$qry->result_array();
        }
        else{
            $data['type']=array();
        }
        return $data;

    }

    function add_partner(){
        $email=$this->input->post('email');

        $this->db->trans_begin();
        $data=array(
            'name'=>$this->input->post('name'),
            'phone'=>$this->input->post('phone'),
            'email'=>$this->input->post('email'),
            'fax'=>$this->input->post('fax'),
            'address'=>$this->input->post('address')
        );
        $this->db->insert('gp_pl_channel_partner',$data);
        $last_channelid=$this->db->insert_id();
        $channel_type=$this->input->post('channel_type');
        foreach($channel_type as $type){
            $data=array(
                'channel_partner_type_id'=>$type,
                'channel_partner_id'=>$last_channelid
            );
            $this->db->insert('gp_pl_channel_partner_type_connection',$data);
        }
        $this->load->helper('string');
        $autopass= random_string('alnum',5);
        $password="channel@".$autopass;
        $logindata=array(
            'email'=>$this->input->post('email'),
            'mobile'=>$this->input->post('phone'),
            'password'=>$password,
            'user_id'=>$last_channelid,
            'type'=>"Channel_partner"
        );
        $user=$this->db->insert('gp_login_table',$logindata);
        $last_userid=$this->db->insert_id();
        $wallete = array(
            array('wallet_type_id' => 2,
                'user_id' => $last_userid,
                'total_value' => 0
            ),
            array('wallet_type_id' => 4,
                'user_id' => $last_userid,
                'total_value' => 0
            )
        );
         $channelpsw['email'] = $this->input->post('email');
         $channelpsw['mobile'] = $this->input->post('phone');
         $channelpsw['psw']= $password;

        $qry3 = $this->db->insert_batch('gp_wallet_values', $wallete);
        $email_message = $this->load->view('admin/edit_email_channelpartner_otp', $channelpsw,TRUE);

        //$ci = get_instance();
        $this->load->library('email');
        $config['protocol'] = "smtp";
        $config['smtp_host'] = "ssl://smtp.gmail.com";
        $config['smtp_port'] = "465";
        $config['smtp_user'] = 'pranavpk.pk1@gmail.com';
        $config['smtp_pass'] = '9544146763';
        $config['charset'] = "utf-8";
        $config['mailtype'] = "html";
        $config['newline'] = "\r\n";

        $this->email->initialize($config);
        $this->email->from('greenindia@gmail.com', 'Green India');
        $this->email->to($email);
        $this->email->reply_to('no-replay@gmail.com', 'OTP Verification');
        $this->email->subject('OTP Verification');
        $this->email->message($email_message);
        $this->email->send();
        $this->db->trans_complete();
        if($this->db->trans_status()===false){
            $this->db->trans_rollback();
            return false;
        }
        else{
            $this->db->trans_commit();
            return true;
        }
    }

    function get_all_partnertype(){
        $qry="select * from gp_pl_channel_partner_types ct where ct.is_del='0' order by ct.id desc";
        $qry=$this->db->query($qry);
        if($qry){
            $data['type']=$qry->result_array();
        }
        else{
            $data['type']=array();
        }
        return $data;

    }

    function get_edit_partnertypebyid(){
        $this->db->trans_begin();
        $id=$this->input->post('hiddentype');
        $data=array(
            'title'=>$this->input->post('title'),
            'description'=>$this->input->post('descriptext')
        );
        $this->db->where('id',$id);
        $this->db->update('gp_pl_channel_partner_types',$data);
        if($this->db->trans_status=false){
            $this->db->trans_rollback();
            return false;
        }
        else{
            $this->db->trans_commit();
            return true;
        }
    }
    function delete_partnertypebyid(){
        $id=$this->input->post('hiddentype');

        $data=array(
            'is_del'=>"1",

        );

        $qry = $this->db->where('id', $id);
        $qry = $this->db->update('gp_pl_channel_partner_types', $data);
        /// $qury;
        return $qry;
    }

    function get_channerpartner(){
        // $qry="select chp.id,chp.name,chp.phone,chp.phone2,chp.email,chp.fax,chp.address,GROUP_CONCAT(ctype.title) from gp_pl_channel_partner chp
        //         left join gp_pl_channel_partner_type_connection typid on typid.channel_partner_id=chp.id
        //         left join gp_pl_channel_partner_types ctype on ctype.id=typid.channel_partner_type_id and ctype.is_del='0'
        //         where chp.is_del='0'
        //         order by chp.id desc";
        $qry = "select
                cp.id as cp_id,
                cp.name, cp.phone,
                cp.phone2,
                cp.email,
                cp.fax,
                cp.address,
                GROUP_CONCAT(typ.title) as cp_type, 
                typ.description
                from
                gp_pl_channel_partner_type_connection con
                left join gp_pl_channel_partner cp on cp.id = con.channel_partner_id
                left join gp_pl_channel_partner_types typ on typ.id = con.channel_partner_type_id
                where cp.is_del='0'
                group by cp.id";
        $query=$this->db->query($qry);
        if($query){
            $data['partner']=$query->result_array();
        }
        else{
            $data['partner']=array();
        }
        return $data;

    }

    function get_channerpartner_byid($id){
        $qry="select chp.id,chp.name,chp.phone,chp.phone2,chp.email,chp.fax,chp.address,GROUP_CONCAT(ctype.title) from gp_pl_channel_partner chp
                left join gp_pl_channel_partner_type_connection typid on typid.channel_partner_id=chp.id
                left join gp_pl_channel_partner_types ctype on ctype.id=typid.channel_partner_type_id and ctype.is_del='0'
                where chp.is_del='0' and chp.id='$id'";
        $query=$this->db->query($qry);
        if($query){
            $data['partner']=$query->row_array();
        }
        else{
            $data['partner']=array();
        }
        return $data;
    }

    function edit_partnerbyid(){
        $this->db->trans_begin();
        $hiddenid=$this->input->post('hiddenid');
        $data=array(
            'name'=>$this->input->post('name'),
            'phone'=>$this->input->post('phone'),
            'phone2'=>$this->input->post('phone2'),
            'email'=>$this->input->post('email'),
            'fax'=>$this->input->post('fax'),
            'address'=>$this->input->post('address')
        );
        $this->db->where('id',$hiddenid);
        $this->db->update('gp_pl_channel_partner',$data);
        if($this->db->trans_status=false){
            $this->db->trans_rollback();
            return false;
        }
        else{
            $this->db->trans_commit();
            return true;
        }
    }

    function delete_partnerbyid($id){

        $data=array(
            'is_del'=>"1",

        );

        $qry = $this->db->where('id', $id);
        $qry = $this->db->update('gp_pl_channel_partner', $data);
        /// $qury;
        return $qry;

    }
    function mail_exisits($mail)
    {

        $qry = "select * from gp_login_table where email = '$mail'";
        $qry = $this->db->query($qry);
        if($qry->num_rows()>0)
        {
            return FALSE;
        } else
        {
            return TRUE;
        }
    }

    function mobile_exisits($mob){
        $qry = "select * from gp_login_table where mobile = '$mob'";
        $qry = $this->db->query($qry);
        if($qry->num_rows()>0)
        {
            return FALSE;
        } else
        {
            return TRUE;
        }
    }

    function get_all_purchasenotification(){
        $session_data=$this->session->userdata('logged_in_admin');
        $loginuser=$session_data['user_id'];

        // $qry = "select logid.mobile,logid.email,noti.wallet_total,noti.id notiid from gp_purchase_bill_notification noti
        //         left join gp_pl_channel_partner_type_connection conid on conid.id=noti.channel_partner_conn_id
        //         left join gp_pl_channel_partner cp on cp.id=conid.channel_partner_id
        //         left join gp_login_table logid on logid.id=noti.customer_id
        //         where logid.id='$loginuser' and noti.status='0'";
        $qry = "select
                noty.id as noty_id,noty.wallet_total,noty.bill_total,
                noty.channel_partner_conn_id,
                noty.wallet_total,
                noty.bill_total,
                DATE_FORMAT(noty.purchased_on, '%Y-%m-%d') as purchased,
                cus.name,
                cus.phone,
                cus.email
                from
                gp_purchase_bill_notification noty
                left join gp_pl_channel_partner_type_connection con on con.id = noty.channel_partner_conn_id
                left join gp_normal_customer cus on cus.id = noty.login_id
                where con.channel_partner_id = '$loginuser' and noty.`status` = 0";
        $qry = $this->db->query($qry);
       // echo $this->db->last_query(); exit;
        if($qry->num_rows()>0)
        {
           // $data['noti']= $qry->result_array();
            $data = $qry->result_array();
        } else
        {
          //  $data['noti']=array();
            $data =array();
        }

        return $data;
    }

    function purchase_otp_confirmation($purcid){
        $data=array(
            'status'=>"1",
        );
        $this->db->where('id',$purcid);
        $query=$this->db->update('gp_purchase_bill_notification',$data);
        return $query;
    }
    function purchase_approval_by_otp(){
        $purcid=$this->input->post('hiddenotp');
        $otp=$this->input->post('purchase_otp');
        $qry="select * from gp_purchase_bill_notification where otp='$otp' and id='$purcid'";
        $res=$this->db->query($qry);
        if($res->num_rows()>0){
           $update = $this->purchase_otp_confirmation($purcid);
           if($update)
           {
                return $res->row_array();
           } else{
                return false;
           }
            
        }
        else{
            return false;
        }
    }
    function get_saled_cat($cp_con_id)
    {

        
         $qry = "select
                *
                from
                gp_channel_con_cat_commision com
                where com.cp_con_id = '$cp_con_id'";
                $qry = $this->db->query($qry);
                if($qry->num_rows()>0)
                {
                    return $qry->result_array();
                }   else{
                    return array();
                }    

        
    }
    function get_purchase_otp(){
        $purcid=$this->input->post('hiddentype_id');
        $mobile=$this->input->post('mobile');
        $this->load->helper('string');
        $otp= random_string('numeric',5);
        $username = "faisal@cybaze.com";
        $hash = "29b89b2ccf079979f19ad3c6ff401b0cddc999ff";

        // Config variables. Consult http://api.textlocal.in/docs for more info.
        $test = "0";

        // Data for text message. This is the text message data.
        $sender = "GREEN INDIA"; // This is who the message appears to be from.
        $numbers = "$mobile"; // A single number or a comma-seperated list of numbers
        $message = "Please use this OTP for completing your purchase :$otp";
        // 612 chars or less
        // A single number or a comma-seperated list of numbers
        $message = urlencode($message);
        $data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
        $ch = curl_init('http://api.textlocal.in/send/?');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);

        $data=array(
            'otp'=>$otp
        );
        $this->db->where('id',$purcid);
        $this->db->update('gp_purchase_bill_notification',$data);
        if($this->db->trans_status=false){
            $this->db->trans_rollback();
            return false;
        }
        else{
            $this->db->trans_commit();
            return $purcid;
        }
    }
    function get_cat_level($con_id)
    {
        $qry = "select
                con.id,
                con.category_level,
                cat.id as cat_id,
                cat.category_title,
                cat.percentage,
                sttgs.pooling_commission,
                sttgs.id as sttgs_id
                from
                gp_pl_channel_partner_type_connection con
                left join gp_channel_con_cat_commision cat on cat.cp_con_id = con.id
                left join gp_pl_system_commission_settings sttgs on sttgs.channel_partner_con_id = con.id
                where con.id = '$con_id'";
        $qry = $this->db->query($qry);
        if($qry->num_rows()>0){
            return $qry->result_array();
        } else{
            return array();
        }
    }
    function get_only_one_cat($con_id)
    {
        $qry = "select
                *
                from
                gp_pl_channel_partner_type_connection con
                where con.id ='$con_id'";
        $qry = $this->db->query($qry);
         if($qry->num_rows()>0)
        {
            return $qry->row_array();
        }else{
            return array();
        } 

    }

    function updatewallet($noty_id, $discount, $data)
    {
         $this->db->trans_begin();
        $qry = "select * from gp_purchase_bill_notification where id ='$noty_id'";
        $qry = $this->db->query($qry);
     //   echo $this->db->last_query();
        if($qry->num_rows()>0)
        {
            $purchase = $qry->row_array();
            $cus_login_id = $purchase['login_id'];

            $this->db->where('id', $noty_id);
            $upqry = $this->db->update('gp_purchase_bill_notification', $data);
          // echo $this->db->last_query();
            $this->db->set('total_value', 'total_value + ' . (float) $discount, FALSE);
            $this->db->where('user_id', $cus_login_id);
            $this->db->where('wallet_type_id', 2);
            $this->db->update('gp_wallet_values'); 

            $reduce_qry = "select * from gp_purchase_bill_noty_wallet_items itm where itm.bill_notification_id ='$noty_id'";
            $reduce_qry = $this->db->query($reduce_qry);
            if($reduce_qry->num_rows()>0)
            {

                $result = $reduce_qry->result_array();
                foreach ($result as $key => $res) {
                  $wal_id = $res['wallet_id'];
                  $wal_val = $res['wallet_value'];

                $this->db->set('total_value', 'total_value - ' . (float) $wal_val, FALSE);
                $this->db->where('id', $wal_id);
                $this->db->update('gp_wallet_values'); 
                }
               
            }else{

            }


            

        }else{
           
        } 
        $this->db->trans_complete();
         if($this->db->trans_status=false){
            $this->db->trans_rollback();
            return false;
        }
        else{
            $this->db->trans_commit();
            return true;
        }
    }
}
?>