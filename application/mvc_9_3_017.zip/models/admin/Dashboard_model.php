<?php
Class Dashboard_model extends  CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    function get_mywallet_value()
    {
        $qry="SELECT total_value FROM `gp_wallet_values` WHERE `user_id` = '13'";

        $result=$this->db->query($qry);
        if($result->num_rows()>0)
        {
            return $result->row_array();
        }
        else
        {
            return array();
        }

    }
}