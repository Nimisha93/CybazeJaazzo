<?php
/**
* 
*/
class Register_model extends CI_Model
{
	
	function __construct()
	{
	    parent::__construct();
        $this->load->database();
	}
	function validate_email($email)
	{
		$data = array();
		//$email = $this->input->post('email');
		
		$qry = "select * from gp_login_table where email = '$email'";
		$qry = $this->db->query($qry);
		if($qry->num_rows()>0)
		{
			$data['reason'] = "Email id already Exists";
			$data['status'] = FALSE;
		} else{
			$data['status'] =  TRUE;
		}
		return $data;
	}
	function validate_phone($phone)
	{
		$data = array();
		
		//$phone = $this->input->post('phone');
		
			$qry2 = "select * from gp_login_table where mobile = '$phone'";
			$qry2 = $this->db->query($qry2);
			if($qry2->num_rows()>0)
			{
				$data['reason'] = "Phone no already Exists";
				$data['status'] = FALSE;
			} else{
				$data['status'] =  TRUE;
			}
			
		
		return $data;
	}
	function customer_registration()
	{
		$data = array();
		$this->db->trans_begin();
		$otp = random_string('numeric', 5);
		$datas = array(
			'phone' => $this->input->post('phone'),
			'email' => $this->input->post('email'),
			'otp' => $otp,
			'reg_otp_status' => 0
			);
		$qry = $this->db->insert('gp_normal_customer', $datas);
		$insert_id = $this->db->insert_id();

		$userLogin = array(
			'mobile' => $this->input->post('phone'),
			'email' => $this->input->post('email'),
			'user_id' => $insert_id,
			'password' => $this->input->post('password'),
			'type' => 'normal_customer'
			); 
		$qry_login = $this->db->insert('gp_login_table', $userLogin);
		$this->db->trans_complete();
		if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        	$data['status'] = FALSE;
        } else {
            $this->db->trans_commit();
            $data['status'] = TRUE;
            $info = array('user_id' => $insert_id,
			            'otp' => $otp
			            	);
            $data['info'] = $info;
        }
        return $data;
	}
	function otp_validate()
	{
		$this->db->trans_begin();
		$data = array();
		$otp = $this->input->post('reg_otp');
		$phone = $this->input->post('mobile');
		$email = $this->input->post('email');
		$qry = "SELECT * from gp_normal_customer c where c.otp = '$otp' and (c.email = '$email' or c.phone = '$phone')";
		$qry = $this->db->query($qry);
		//var_dump($this->db->last_query());exit;
		if($qry->num_rows()>0)
		{

			$user_details = $qry->row_array();
			$user_id = $user_details['id'];

			

			$qry_res = "SELECT * from gp_login_table tb where tb.user_id = '$user_id' and tb.type = 'normal_customer'";
			$qry_res = $this->db->query($qry_res);
			if($qry_res->num_rows()>0)
			{
				$login_details = $qry_res->row_array();
				$login_id = $login_details['id'];

				$update_status = array('otp_status' => 1);
				$this->db->where('id', $login_id);
				$upqry = $this->db->update('gp_login_table', $update_status);


				$wallete = array(
							array('wallet_type_id' => 2,
									'user_id' => $login_id,
									'total_value' => 0
									),
							array('wallet_type_id' => 4,
									'user_id' => $login_id,
									'total_value' => 0
									)
							);
				
				$qry3 = $this->db->insert_batch('gp_wallet_values', $wallete);
				$this->db->trans_complete();
				$data['info'] =  $login_details;
				$data['status'] = TRUE;
			} else{
				$data['info'] =  array();
				$data['status'] = FALSE;
			}
		}
		return $data;		
	}
	function club_registration()
	{
		$data = array();
		$this->db->trans_begin();
		$otp = random_string('numeric', 5);
		$datas = array(
			'name' => $this->input->post('cl_reg_name'),
			'phone' => $this->input->post('cl_reg_mobile'),
			'email' => $this->input->post('cl_reg_mail'),
			'otp' => $otp,
			'reg_otp_status' => 0
			);
		$qry = $this->db->insert('gp_normal_customer', $datas);
		$insert_id = $this->db->insert_id();

		$userLogin = array(
			'mobile' => $this->input->post('cl_reg_mobile'),
			'email' => $this->input->post('cl_reg_mail'),
			'user_id' => $insert_id,
			'password' => $this->input->post('cl_reg_pass'),
			'type' => 'normal_customer'
			); 
		$qry_login = $this->db->insert('gp_login_table', $userLogin);
		$this->db->trans_complete();
		if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        	$data['status'] = FALSE;
        } else {
            $this->db->trans_commit();
            $data['status'] = TRUE;
            $info = array('user_id' => $insert_id,
			            'otp' => $otp
			            	);
            $data['info'] = $info;
        }
        return $data;
	}
		function otp_validate_reg()
	{
		$this->db->trans_begin();
		$data = array();
		$otp = $this->input->post('otp_reg_confirm');
		$phone = $this->input->post('otp_reg_phone');
		$email = $this->input->post('otp_reg_email');
		$qry = "SELECT * from gp_normal_customer c where c.otp = '$otp' and (c.email = '$email' or c.phone = '$phone')";
		$qry = $this->db->query($qry);
		//var_dump($this->db->last_query());exit;
		if($qry->num_rows()>0)
		{

			$user_details = $qry->row_array();
			$user_id = $user_details['id'];
			$qry_res = "SELECT * from gp_login_table tb where tb.user_id = '$user_id' and tb.type = 'club_member'";
			$qry_res = $this->db->query($qry_res);
			if($qry_res->num_rows()>0)
			{
				$login_details = $qry_res->row_array();
				$login_id = $login_details['id'];

				$update_status = array('otp_status' => 1);
				$this->db->where('id', $login_id);
				$upqry = $this->db->update('gp_login_table', $update_status);


				$wallete = array(
							array('wallet_type_id' => 2,
									'user_id' => $login_id,
									'total_value' => 0
									),
							array('wallet_type_id' => 4,
									'user_id' => $login_id,
									'total_value' => 0
									)
							);
				
				$qry3 = $this->db->insert_batch('gp_wallet_values', $wallete);
				$this->db->trans_complete();
				$data['info'] =  $login_details;
				$data['status'] = TRUE;
			} else{
				$data['info'] =  array();
				$data['status'] = FALSE;
			}
		}
		return $data;		
	}
	function become_club_member()
	{
		$this->db->trans_begin();
		$id = $this->input->post('user_id');
		$data = array('club_type_id' => $this->input->post('club_plan'));
		$this->db->where('id', $id);
		$upqry = $this->db->update('gp_normal_customer', $data);

		$qry_login = "select * from gp_login_table where user_id = '$id' and type = 'normal_customer'";
		$qry_login = $this->db->query($qry_login);
		if($qry_login->num_rows()>0)
		{
			$get_details = $qry_login->row_array();
			$login_id = $get_details['id'];
			$wallete = array('wallet_type_id' => 1,
						'user_id' => $login_id,
						'total_value' => 0
					);
			$qry3 = $this->db->insert('gp_wallet_values', $wallete);
		}else{
			$get_details = array();
		}
		
		$up_data = array('type' => 'club_member');
		$this->db->where('user_id', $id);
		$this->db->where('type', 'normal_customer');
		$qry = $this->db->update('gp_login_table', $up_data);

		
		$this->db->trans_complete();
		if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        	return FALSE;
        } else {
            $this->db->trans_commit();
            return TRUE;
            
        }

	}
}
?>