<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 */

Class Pooling extends CI_Controller
{

    function __Construct(){

        parent:: __construct();
        $this->load->library(array('session','form_validation'));
        $this->load->model(array('admin/Pooling_model','admin/Channelpartner_model'));
        $this->load->helper(array('url','form'));

    }

    function set_menu(){
        $data['default_assets'] = $this->load->view('admin/templates/default_assets', '', true);
        $data['sidebar'] = $this->load->view('admin/templates/cp_sidebar', '', true);
        $data['footer'] = $this->load->view('admin/templates/admin_footer', '', true);
        return $data;
    }


    //add new pool form
    function new_pool()
    {
        $data['default_assets']=$this->load->view('admin/templates/default_assets','',true);
        $data['sidebar']=$this->load->view('admin/templates/admin_sidebar','',true);
        $data['footer']=$this->load->view('admin/templates/admin_footer','',true);
        $data['designations']= $this->Pooling_model->get_all_desiginations();
        $data['total_group_persantage']=$this->Pooling_model->get_total_group_persantage();
//        $data['bal_group_persantage']=100-$data['total_group_persantage'];
        // echo json_encode($data['total_group_persantage']);
        if($data['total_group_persantage']['total_persantage']==100)
        {
            $data['pesantage_limit']='over_flow';
            $this->load->view('admin/edit_add_system_pool',$data);
        }
        else
        {
            $data['pesantage_limit']='succes';
            $this->load->view('admin/edit_add_system_pool',$data);
        }


    }
    //add new pool data
    function  add_new_pool_data()
    {
        if($this->input->is_ajax_request())
        {
            $this->form_validation->set_rules("pool_name", "Pool Group Name", "trim|required|htmlspecialchars");
            $this->form_validation->set_rules("allow_persantage", "Group Allow Persantage", "numeric|trim|required|htmlspecialchars");
            $this->form_validation->set_rules("no_of_levels", "No of Levels ", "numeric|trim|required|htmlspecialchars");
            $this->form_validation->set_rules("design_allwed_persantage[]", "Designation allowed persantage  ", "numeric|trim|required|htmlspecialchars");

            if($this->form_validation->run()== TRUE){
                $result=$this->Pooling_model->add_new_pool_data();
                if($result)
                {
                    exit(json_encode(array("status"=>TRUE)));
                }
                else{
                    exit(json_encode(array("status"=>FALSE,"reason"=>'Database Error')));
                }



            }
            else
            {
                exit(json_encode(array("status"=>FALSE,"reason"=>validation_errors())));
            }
        }
        else
        {

            show_error("We are unable to process this request on this way!");
        }
    }
    //view edit pool group data form
    function  view_pool_group_settings()
    {
        $data['default_assets']=$this->load->view('admin/templates/default_assets','',true);
        $data['sidebar']=$this->load->view('admin/templates/admin_sidebar','',true);
        $data['footer']=$this->load->view('admin/templates/admin_footer','',true);
        $data['pooling_groups']= $this->Pooling_model->get_all_group_pooing();
        $this->load->view('admin/edit_view_group_pooling',$data);
    }
    //view full pooling settings form
    function full_system_pool_settings($id)
    {
        $data['default_assets']=$this->load->view('admin/templates/default_assets','',true);
        $data['sidebar']=$this->load->view('admin/templates/admin_sidebar','',true);
        $data['footer']=$this->load->view('admin/templates/admin_footer','',true);
        $data['pooling_details']= $this->Pooling_model->get_all_system_pooing_by_id($id);
        $data['designations']= $this->Pooling_model->get_all_desiginations();

        echo json_encode($data['pooling_details']);

        $this->load->view('admin/edit_view_full_pool_settings',$data);
    }

    //get pooling data by id
    function get_pooling_data_by_id()
    {

    }

    //delete system pooling group
    function delete_system_pool_group($id)
    {
        $result=$this->Pooling_model->delete_system_pool_group($id);
        if($result){
            exit(json_encode(array("status"=>TRUE)));
        }
        else{
            exit(json_encode(array("status"=>FALSE,"reason"=>"Database Error")));
        }
    }
    //add new designation  form
    function new_designation()
    {
        $data['default_assets']=$this->load->view('admin/templates/default_assets','',true);
        $data['sidebar']=$this->load->view('admin/templates/admin_sidebar','',true);
        $data['footer']=$this->load->view('admin/templates/admin_footer','',true);
        $this->load->view('admin/edit_add_designation',$data);

    }
    //add new designation
    function  add_designation()
    {
//        // Here you will get data from angular ajax request in json format so you have to decode that json data you will get object array in $request variable
//
////        $postdata = file_get_contents("php://input");
////        $request = json_decode($postdata);
//
//        $data=array(
//            'designation' => $request->designation,
//            'sort_order'   => $request->sortorder,
//            'description' => $request->discription
//        );
//
//
//        $result=$this->pooling_model->add_designation($data);
//
//        if($result)
//        {
//            echo $result = '{"status" : "success"}';
//        }else
//        {
//            echo $result = '{"status" : "failure"}';
//        }
        if($this->input->is_ajax_request())
        {

            $this->form_validation->set_rules("Desigination", "Desigination ", "trim|required|htmlspecialchars");
            $this->form_validation->set_rules("Sortorder", "Direct Commission", "numeric|trim|required|htmlspecialchars");
            $this->form_validation->set_rules("discription", "Discription ", "trim|required|htmlspecialchars");

            if($this->form_validation->run()== TRUE){
                $result=$this->Pooling_model->add_designation();

                if($result){
                    exit(json_encode(array("status"=>TRUE)));
                }
                else{

                    exit(json_encode(array("status"=>FALSE,"reason"=>"Database Error")));
                }
            }
            else{
                exit(json_encode(array("status"=>FALSE,"reason"=>validation_errors())));
            }
        }
    }

    //check sort order of desiginations
    function  check_sort_order()
    {
        if($this->input->is_ajax_request())
        {


            $result=$this->Pooling_model->check_sort_order();

            if($result){
                exit(json_encode(array("status"=>TRUE)));
            }
            else{

                exit(json_encode(array("status"=>FALSE,"reason"=>"Database Error")));
            }

        }
    }
    //view  all  designation
    function get_all_desiginations()
    {
        $result=$this->pooling_model->get_all_desiginations();

    }

    function new_commision(){
        $data=$this->set_menu();
        $data['partner_type']=$this->Pooling_model->get_partner_type();
        $this->load->view('admin/edit_add_commmission',$data);
    }
    function new_commision_add(){

        if($this->input->is_ajax_request()){
            $this->form_validation->set_rules("main_commission", "Main Commision ", "numeric|trim|required|htmlspecialchars");
            $this->form_validation->set_rules("channel_type", "Channel Partner Type ", "trim|required|htmlspecialchars");
            $this->form_validation->set_rules("direct_commission", "Direct Commission", "numeric|trim|required|htmlspecialchars");
            $this->form_validation->set_rules("pooling_commission", "Company Commission ", "numeric|trim|required|htmlspecialchars|greater_than[5]");

            if($this->form_validation->run()== TRUE){
                $result=$this->Pooling_model->add_new_commission();

                if($result){
                    exit(json_encode(array("status"=>TRUE)));
                }
                else{

                    exit(json_encode(array("status"=>FALSE,"reason"=>"Database Error")));
                }
            }
            else{
                exit(json_encode(array("status"=>FALSE,"reason"=>validation_errors())));
            }
        }
    }

    function get_commision_all(){

        $data=$this->set_menu();
        $data['partner_type']=$this->Pooling_model->get_partner_type();

        $data['commission']=$this->Pooling_model->get_all_commision();
        $this->load->view('admin/edit_view_pooling',$data);

    }

    function delete_commissionbyid($id){

    $result=$this->Pooling_model->delete_commission($id);
    if($result){
        exit(json_encode(array("status"=>TRUE)));
    }
    else{
        exit(json_encode(array("status"=>FALSE,"reason"=>"Database Error")));
    }
    }

    function edit_pooling_byid(){
        if($this->input->is_ajax_request()){

            $this->form_validation->set_rules("channel_type", "Channel Partner Type ", "trim|required|htmlspecialchars");
            $this->form_validation->set_rules("direct_commi", "Direct Commission", "trim|required|htmlspecialchars");
            $this->form_validation->set_rules("company_commi", "Pooling Commission ", "trim|required|htmlspecialchars");

            if($this->form_validation->run()== TRUE){
                $result=$this->Pooling_model->edit_commission_byid();

                if($result){
                    exit(json_encode(array("status"=>TRUE)));
                }
                else{

                    exit(json_encode(array("status"=>FALSE,"reason"=>"Database Error")));
                }
            }
            else{
                exit(json_encode(array("status"=>FALSE,"reason"=>"Validation Error")));
            }
        }

    }
function effect_customer($purch_id)
{
    $result = $this->pooling_model->effect_cutomer($purch_id);
}




}
?>