<?php
Class Product_model extends CI_Model{

    function __construct(){
        parent:: __construct();
        $this->load->database();
    }

    function get_category(){
        $qry="select pc.title,pc.description,pc.image,pc.parent_id,pc.id from gp_product_category pc where pc.is_del='0'";
        $qry=$this->db->query($qry);
        if($qry){
            $data['category']=$qry->result_array();
        }
        else{
            $data['category']=array();
        }
        return $data;

    }

    function add_new_product($image_file){
        $this->db->trans_begin();



        $data=array(
            'category_id'=>$this->input->post('pro_category'),
            'name'=>$this->input->post('pro_name'),
            'quantity'=>$this->input->post('pro_quantity'),
            'description'=>$this->input->post('pro_description'),
            'model'=>$this->input->post('pro_model'),
            'actual_cost'=>$this->input->post('pro_actualcost'),
            'image'=>$image_file,
            'cost'=>$this->input->post('pro_cost'),
        );
        $this->db->insert('gp_product_details',$data);
        if($this->db->trans_status=false){
            $this->db->trans_rollback();
            return false;
        }
        else{
            $this->db->trans_commit();
            return true;
        }
    }

    function get_all_product(){
        $qry="select p.*,pc.title from gp_product_details p
              left join gp_product_category pc on pc.id=p.category_id
              where p.is_del='0'";
        $qry=$this->db->query($qry);
        if($qry){
            $data['produ']=$qry->result_array();
        }
        else{
            $data['produ']=array();
        }
        return $data;

    }

    function get_product_byid($id){
        $qry="select p.*,pc.title from gp_product_details p
              left join gp_product_category pc on pc.id=p.category_id
              where p.id='$id'";
        $qry=$this->db->query($qry);
        if($qry){
            $data['produ']=$qry->row_array();
        }
        else{
            $data['produ']=array();
        }
        return $data;

    }

    function edit_product_byid($image_file,$id){
        $this->db->trans_begin();



        $data=array(
            'category_id'=>$this->input->post('pro_category'),
            'name'=>$this->input->post('pro_name'),
            'quantity'=>$this->input->post('pro_quantity'),
            'description'=>$this->input->post('pro_description'),
            'model'=>$this->input->post('pro_model'),
            'actual_cost'=>$this->input->post('pro_actualcost'),
            'image'=>$image_file,
            'cost'=>$this->input->post('pro_cost'),
        );
        $this->db->where('id',$id);
        $this->db->update('gp_product_details',$data);
        if($this->db->trans_status=false){
            $this->db->trans_rollback();
            return false;
        }
        else{
            $this->db->trans_commit();
            return true;
        }
    }


}
?>