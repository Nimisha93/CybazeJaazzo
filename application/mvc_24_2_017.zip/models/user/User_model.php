<?php
/**
* 
*/
class User_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	function get_wallete_values_user($login_id)
	{
		$qry = "select
				wal.id,
				wal.wallet_type_id,
				typ.title,
				wal.user_id,
				wal.total_value
				from
				gp_wallet_values wal
				
				left join gp_wallet_types typ on  typ.id = wal.wallet_type_id
				where wal.user_id = ?
				order by typ.title asc";
		$qry = $this->db->query($qry, $login_id);
		if($qry->num_rows()>0)
		{
			return $qry->result_array();
		} else{
			return array();
		}		
	}
	function get_channel_partner()
	{
		$qry = "select
				con.id as con_id,
				cp.name,
				cp.phone,
				typ.title as shope_type,
				typ.`status`
				from
				gp_pl_channel_partner_type_connection con

				left join gp_pl_channel_partner cp on cp.id = con.channel_partner_id
				left join gp_pl_channel_partner_types typ on typ.id = con.channel_partner_type_id";
		$qry = $this->db->query($qry);
		if($qry->num_rows()>0)
		{
			return $qry->result_array();
		} else{
			return array();
		}	

	}
}

?>