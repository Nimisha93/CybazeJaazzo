<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8' />
    <title>Green India</title>
    <meta name='viewport' content='width=device-width, initial-scale=1.0' />
</head>
<body>
<table width='100%' border='0' cellspacing='0' cellpadding='0' align='center' style='background:url(<?php echo base_url();?>style/dist/img/bg.jpg) repeat;'>



    <tbody>


    <tr>
        <td align='center' valign='top'>

            <table cellpadding='0' cellspacing='0' align='center' bgcolor='#ffffff' style=' background:#FFFFFF; border:1px solid #e3e3e3; border-radius: 3px; max-width:582px'>


                <tbody>





                <tr>


                    <td width='580' align='center' style='padding:5px;background-color: #124761;'><table border='0' cellpadding='0' cellspacing='0' align='center' style='max-width:570px;'>



                        <tbody>

                        <tr>



                            <td align='center' valign='top'>


                                <a href='#' style='display:block;'>

                                    <div style='width:100%'><img src='<?php echo base_url();?>style/dist/img/logolg.png' border='0' alt='' style='margin:0; display:block; max-width:570px; width:inherit' vspace='0' hspace='0' align='absmiddle'>

                                    </div></a></td>





                        </tr>


                        </tbody></table></td>







                </tr>



                <tr>
                    <td style='border:1px solid #124761;'>

                    </td>
                </tr>


                <tr>
                    <td width='580' align='center' style='padding:15px;'> <table width='100%' border='0' align='center' cellpadding='0' cellspacing='0' style='max-width:540px;'>
                        <tbody>
                        <tr bgcolor='#ffffff'>
                            <td width='540' align='left' style='font-size:14px; color:#333333; font-family: 'Open Sans', Gill Sans, Arial, Helvetica, sans-serif;'>Dear Sir/Madam,
                            <br><br> <?php echo $message;?><br><br>

                            </td>
                        </tr>
                        </tbody>
                    </table></td>
                </tr>





                <tr>
                    <td width='580' align='center' style='padding:15px;'> <table width='100%' border='0' align='center' cellpadding='0' cellspacing='0' style='max-width:550px;'>
                        <tbody>
                        <tr bgcolor='#ffffff'>
                            <td width='540' align='left' style=' font-size:14px; color:#333333; font-family: 'Open Sans', Gill Sans, Arial, Helvetica, sans-serif;'>
                            <br><br>Sincerely<br>
                            Team Arooha</td>
                        </tr>
                        <tr>
                            <td height='20'></td>
                        </tr>

                        <tr>
                            <td align='center' style=' line-height:13px; font-size:11px; font-family: Helvetica,Arial,sans-serif;     color: #ffffff;
    padding-bottom: 10px;
    padding-top: 10px;
    background-color: #124761;'> <a href='#' target='_blank' style='color:#ffffff; text-decoration:none;'>Arooha Holidays</a></td>
                        </tr>
                        </tbody>
                    </table></td>
                </tr>

                </tbody>

            </table>





        </td>
    </tr>
    </tbody></table>
</body>
</html>