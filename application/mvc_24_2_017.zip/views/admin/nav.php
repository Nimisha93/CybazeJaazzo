 </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col ">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;background-color:#84868b">
           
             <a href="index.html" class="site_title whiteclr"><i class="fa fa-cogs rght5mrgn whiteclr" aria-hidden="true"></i>Operation</a>
              
                
            </div>

            <div class="clearfix"></div>
	       
            <!-- menu profile quick info -->
           <div class="profile clearfix">
              <div class="profile_pic">
                <img src="../images/img.jpg" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>Sumesh k k</h2>
                
              
              
              </div>
            </div>
            <!-- /menu profile quick info -->

         

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
            
                <ul class="nav side-menu">
                
                
          
              
                  <li><a href="dashboard.php"><i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard </a></li>
                 
                  <li><a><i class="fa fa fa-cog" aria-hidden="true"></i>System Commision Settings <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="system-commision.php">System Commision Settings</a></li>
                      
                      
                    </ul>
                  </li>
                  
                     <li><a><i class="fa fa-user" aria-hidden="true"></i>Channel Partner <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="add-channel-partner.php">Add Channel Partner</a></li>
                      
                    </ul>
                  </li>
                  
                  
                  <li><a><i class="fa fa-graduation-cap" aria-hidden="true"></i>Designation<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="add--designation.php">Add Designation</a></li>
                    
                    </ul>
                  </li>
                  
                  
                   <li><a><i class="fa fa-user" aria-hidden="true"></i>Team Member <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="add-team-member.php">Add Team Member</a></li>
                      
                    </ul>
                  </li>
                  
                   <li><a><i class="fa fa-user-circle" aria-hidden="true"></i>Club Member <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="add-club-member.php">Add Club Member</a></li>
                      <li><a href="add-clubmember-type.php">Add Club Member Type</a></li>
                    </ul>
                  </li>
                  
                  
                   <li><a><i class="fa fa-archive" aria-hidden="true"></i>Products <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="add-products.php">Add Products</a></li>
                      
                    </ul>
                  </li>
                  
                   <li><a><i class="fa fa-thumbs-up" aria-hidden="true"></i>Deals <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="add-new-deals.php">Add New Deals</a></li>
                      
                    </ul>
                  </li>
                  
                     
                   <li><a><i class="fa fa-pie-chart" aria-hidden="true"></i>Reports <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="all-product-report.php">All Products Report</a></li>
                      <li><a href="total-customer-report.php">Totel Cutomers Report</a></li>
                       <li><a href="purchase-report.php">Purchase Report</a></li>
                        
                    </ul>
                  </li>
                  
                  <li><a href="c"><i class="fa fa-star" aria-hidden="true"></i>Activity Log </a>
                    
                  </li>
                  
                   <li><a href="c"><i class="fa fa-question-circle" aria-hidden="true"></i>Enquery </a>
                    
                  </li>
                  
                   
                  
                   
                  
                </ul>
              </div>
          
          <div class="menu_section">
                <h3>Common</h3>
                <ul class="nav side-menu">
                  <li><a href="calendar.php"><i class="fa fa-calendar"></i> Calendar </a>
                    <!--<ul class="nav child_menu">
                      <li><a href="e_commerce.html">E-commerce</a></li>
                      <li><a href="projects.html">Projects</a></li>
                      <li><a href="project_detail.html">Project Detail</a></li>
                      <li><a href="contacts.html">Contacts</a></li>
                      <li><a href="profile.html">Profile</a></li>
                    </ul>-->
                  </li>
                  <li><a href="#"><i class="fa fa-envelope-o"></i> Notification </a> </li>
                  <li><a href="#"><i class="fa fa-bell-o"></i> Inbox </a></li>
                   <li><a><i class="fa fa-user-plus"></i> System Administration <span class="fa fa-chevron-down"></span></a>
                   
                   <ul class="nav child_menu">
                      <li><a href="profile.php">My Profile</a></li>
                      <li><a href="#">Account Settings</a></li>
      <li> <a href="#">Sign Out</a></li>

                    </ul>
                    
                     </li>
                       
                    </ul>
                  </li>                  
               
                </ul>
              </div>
            </div>
        
          </div>
        </div>
  
        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
         
       
        
            
             
              
              
                  <nav>
             
 
  
              <ul class="nav navbar-nav navbar-right">
           
              
              <li class="">
                 
                   <img src="../images/online-portal-logo.png" style="height:50px;">
               
                  
                </li>
                
                
                <li class="help"><a href="#" > <i class="fa fa-question-circle" aria-hidden="true"></i></a> </li>
                
                <li class="profl1 dropdown">
              <a href="#" class="dropdown-toggle" ><i class="fa fa-user-plus"></i><span class=""> </span></a>
              
              <ul class="dropdown-menu ">
               <h4>System Administration</h4>
  <li> <a href="profile.php"><i class="fa fa-user" style="margin-right:6px;"></i>My Profile</a></li>
   <li> <a href="#"><i class="fa fa-cog" style="margin-right:6px;"></i>Account Settings</a></li>
      <li> <a href="#"><i class="fa fa-sign-out" style="margin-right:6px;"></i>Sign Out</a></li>



              </ul>
            </li>
            
            
              </ul>
            </nav>
            
             
        <div class="nav toggle lft10">

                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
          
            <ul class="add-mdulebtton">
        
         <li role="presentation" class="dropdown" style="margin-top:15px;">
                  <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                   <span class="addmdlbtn"> + </span>
                    
                  </a>
                   <ul id="menu1" class="dropdown-menu mnu-itms" role="menu">
                  <div class="col-sm-6">
                 <h2 class="sales">Sales</h2>
    <li><a id="fc_create" data-toggle="modal" data-target="#newcstomr"><span class="sbmnu1" style="margin-right:6px;">+</span>Customer</a> </li>
     <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Log Time</a> </li>  
      <li> <a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Sales order</a> </li>
      <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Estmate</a> </li>  
    <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Retailer Invoice</a> </li> 
   <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Invoice</a> </li>  
    <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Customer Payment</a> </li>   
                  
                  </div>
                  
                       <div class="col-sm-6">
                 <h2 class="prchs">Purchases</h2>
    <li><a id="fc_create" data-toggle="modal" data-target="#newcstomr"><span class="sbmnu1" style="margin-right:6px;">+</span>Customer</a> </li>
     <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Log Time</a> </li>  
      <li> <a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Sales order</a> </li>
      <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Estmate</a> </li>  
    <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Retailer Invoice</a> </li> 
   <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Invoice</a> </li>  
    <li><a href=""><span class="sbmnu1" style="margin-right:6px;">+</span>Customer Payment</a> </li>   
                  
                  </div>
                  
                  </ul>
                </li>
                
         </ul>
           
            <nav class="navbar navbar-inverse fllft hidemobilmenu" role="navigation" >
      <div class="">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <i class="fa fa-caret-down" aria-hidden="true"></i>
          </button>
          
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
         
               
          <ul class="nav navbar-nav">
            
            
            <li >
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-home"></i><span class="mnulist">Home</span></a>
             
            </li>
            
            
         
            
            <!--=================== add button end here=========================================-->
          
            
            <li class="dropdown">
              <a href="add-ledger.html" class="dropdown-toggle" ><i class="fa fa-cog"></i><span class="mnulist">Organization</span></a>
              <ul class="dropdown-menu accntsubmnuhide">
              <h4>Organization</h4>
               
                <li><a href="companies.php"><i class="fa fa-trello" style="margin-right:6px;"></i>Companies</a></li>
                <li><a href=""><i class="fa fa-building" style="margin-right:6px;"></i>Stations</a></li>
                 <li><a href=""><i class="fa fa-sitemap" style="margin-right:6px;"></i>Departments</a></li>
                <li><a href=""><i class="fa fa-archive" style="margin-right:6px;"></i>Projects</a></li>
                 <li><a href="system-settings.php"><i class="fa fa-cog" style="margin-right:6px;"></i>System Settings</a></li>
                  <li><a href=""><i class="fa fa-file-text-o" style="margin-right:6px;"></i>System Logs</a></li>
               
               
                
                
              </ul>
            </li>
            
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" ><i class="fa fa-address-card"></i><span class="mnulist">Recruitment</span></a>
              <ul class="dropdown-menu accntsubmnuhide">
              <h4>Recruitment</h4>
              
                <li><a href="#"><i class="fa fa-envelope-o" style="margin-right:6px;"></i>Job Posts</a></li>
                <li><a href="#"><i class="fa fa-user-o" style="margin-right:6px;"></i>Job Candidates</a></li>
                  <li><a href="#"><i class="fa fa-ticket" style="margin-right:6px;"></i>Requisitions</a></li>
                <li><a href="#"><i class="fa fa-id-badge" style="margin-right:6px;"></i>Shortlist Candidates</a></li>
                
              </ul>
            </li>
            
               <li class="dropdown">
               
              <a href="chart-account.html" class="dropdown-toggle" ><i class="fa fa-user"></i><span class="mnulist">Employees</span></a>
              
             
             
              <ul class="dropdown-menu accntsubmnuhide">
               <h4>Employees</h4>
               
               
                <li> <a href=""><i class="fa fa-user" style="margin-right:6px;"></i>Employees</a></li>
   <li> <a href=""><i class="fa fa-user-o" style="margin-right:6px;"></i>Employees Joinig</a></li>
              <li> <a href=""><i class="fa fa-random" style="margin-right:6px;"></i>Requisitions</a></li>
   <li> <a href=""><i class="fa fa-chain-broken" style="margin-right:6px;"></i>Resignations</a></li>
   <li> <a href=""><i class="fa fa-wpforms" style="margin-right:6px;"></i>Complaints</a></li>
                <li> <a href="#"><i class="fa fa-exclamation-triangle" style="margin-right:6px;"></i>Warnings</a></li>
            <li> <a href=""><i class="fa fa-stop-circle-o" style="margin-right:6px;"></i>Terminations</a></li>
   <li> <a href=""><i class="fa fa-external-link-square" style="margin-right:6px;"></i>Employees Exit</a></li>
            
                </ul>  
            </li>
            
            
            
                 <li class="dropdown">
              <a href="#" class="dropdown-toggle" ><i class="fa fa-file-o"></i><span class="mnulist"> Balance Sheet</span></a>
              <ul class="dropdown-menu accntsubmnuhide">
                <h4>Balance Sheet</h4>
  <li> <a href="#"><i class="fa fa-address-card-o" style="margin-right:6px;"></i>Attendance</a></li>
   <li> <a href="#"><i class="fa fa-clock-o" style="margin-right:6px;"></i>Employee Hours</a></li>
     <li> <a href="#"><i class="fa fa-address-book-o" style="margin-right:6px;"></i>Leaves</a></li>
   <li> <a href="#"><i class="fa fa-file-text" style="margin-right:6px;"></i>Worksheet</a></li>
   <li> <a href="#"><i class="fa fa-clone" style="margin-right:6px;"></i>Work Shifts</a></li>
   <li> <a href="#"><i class="fa fa-file-excel-o" style="margin-right:6px;"></i>Holidays</a></li>

              </ul>
            </li>
            
            
            
                   <li class="dropdown">
              <a href="#" class="dropdown-toggle" ><i class="fa fa-calculator"></i><span class="mnulist"> Payroll</span></a>
              <ul class="dropdown-menu accntsubmnuhide">
               <h4>Payroll</h4>
  <li> <a href="#"><i class="fa fa-inr" style="margin-right:6px;"></i>Salary</a></li>
   <li> <a href="#"><i class="fa fa-file-archive-o" style="margin-right:6px;"></i>Salary Payslips</a></li>
     <li> <a href="#"><i class="fa fa-database" style="margin-right:6px;"></i>Payroll Structure</a></li>
   <li> <a href="#"><i class="fa fa-file-excel-o" style="margin-right:6px;"></i>Deductions</a></li>
   <li> <a href="#"><i class="fa fa-cart-plus" style="margin-right:6px;"></i>Bonuses</a></li>
     <li> <a href="#"><i class="fa fa-adjust" style="margin-right:6px;"></i>Adjustments</a></li>
   <li> <a href="#"><i class="fa fa-credit-card-alt" style="margin-right:6px;"></i>Reimbursements</a></li>
   <li> <a href="#"><i class="fa fa-clock-o" style="margin-right:6px;"></i>Overtimes</a></li>
     <li> <a href="#"><i class="fa fa-money" style="margin-right:6px;"></i>Provident Fund</a></li>
   <li> <a href="#"><i class="fa fa-credit-card" style="margin-right:6px;"></i>Advance Salary</a></li>


              </ul>
            </li>
            
              <li class="dropdown">
              <a href="#" class="dropdown-toggle" ><i class="fa fa-pie-chart"></i> <span class="mnulist"> Reports</span></a>
              <ul class="dropdown-menu accntsubmnuhide">
              <h4>Reports</h4>
  <li> <a href="#"><i class="fa fa-globe" style="margin-right:6px;"></i>HR Reports</a></li>
   <li> <a href="#"><i class="fa fa-file-archive-o" style="margin-right:6px;"></i>Recruitment Reports</a></li>
     <li> <a href="#"><i class="fa fa-file-text-o" style="margin-right:6px;"></i>Employees Reports	</a></li>
   <li> <a href="#"><i class="fa fa-file-text" style="margin-right:6px;"></i>Timesheet Reports</a></li>
     <li><a href="#"><i class="fa fa-line-chart" style="margin-right:6px;"></i>Payroll Reports</a></li>
          </ul>
          
          
          </li>
          
          
               
                   
            
              <li>
              <a href="#" ><i class="fa fa-calendar"></i><span class="mnulist"> Settings</span></a>
           </li>
           
           
               <li>
              <a href="#" ><i class="fa fa-envelope-o" style="margin-right:0px;"></i><span class="mnulist"> Settings</span></a>
           </li>
           
           
          <li class="dropdown">
              <a href="#" class="dropdown-toggle"  ><i class="fa fa-bell-o"></i><span class="mnulist"> Notification</span></a>
              <ul class="dropdown-menu notictn accntsubmnuhide">
              
              
               <h4>Notification</h4>
  <li> <a href="#"style="color:#039"><i class="fa fa-check" style="margin-right:6px;"></i> marked all as read</a></li>
   <li style="float:left;"> <a href="#" style="color:#039"> <i class="fa fa-globe" style="margin-right:6px;"></i> All notification</a></li>
   
 
   <div class="col-md-12 col-sm-12">
   
    <p class="ntfctin"> <a href="#">No notification </a> </p>
   
</div>

              </ul>
            </li>
            
          
          
          
                   
            
            
              
          </ul>

          
        </div>
        <!-- /.navbar-collapse -->
      </div>
      <!-- /.container-fluid -->
    </nav>
            
          </div>
        </div>