<div class="clear"></div>






<footer class="footr_bgclr1">
  <section>
    <div class="container top_pad30 botm_pad30">
      <h3 class="text-center ">Greenindia On Mobile</h3>
      <div class="border3">
        <div class="col-md-5 col-sm-5 wow slideInLeft tp_mar30">
          <div class="col-md-4 col-sm-4 col-xs-4"> <a href=""><img src="<?= base_url();?>assets/public/images/playstore.png"></a> </div>
          <div class="col-md-4 col-sm-4 col-xs-4"> <a href=""><img src="<?= base_url();?>assets/public/images/appstore.png"></a> </div>
          <div class="col-md-4 col-sm-4 col-xs-4"> <a href=""><img src="<?= base_url();?>assets/public/images/wndsstore.png"></a> </div>
        </div>
        <div class="col-md-1 col-sm-1 tp_mar30">
          <div class="fntbld tp_mar10 fntsz1 text-center whit2">OR</div>
        </div>
        <div class="col-md-6 col-sm-6 wow slideInRight">
          <form>
            <div class="col-md-12 col-sm-12 col-xs-12 ">
              <label class="fntsz2 whit2">Download via SMS</label>
              <input type="text" class="txt_bg1" id="usr" placeholder="Enter Your Mobile number">
              <button type="submit" class="button_submit1" value="Submit">Submit</button>
              <label class="fntsz3 whit2">Or you can also give a missed call on 080888888 to download the greenindia app</label>
            </div>
          </form>
        </div>
      </div>
    </div>
    
    <!--===========container end here ========================-->
    
    <div class="clear"></div>
    <div class="container top_pad30">
      <h3 class="text-center">plan trips, add places, write reviews & see where friends have been!</h3>
      <div class="border1 bm_mar20">
        <div class="clear"></div>
        <div class="col-md-2 col-sm-2 wow slideInLeft tp_mar20"> </div>
        <div class="col-md-8 col-sm-8 tp_mar20">
          <div class="col-md-6 col-sm-6 col-xs-12 wow slideInLeft"> <a href="">
            <div class="fbbx"> <i class="fa fa-facebook fntsz1 pd2" aria-hidden="true"></i>Login with Facebook </div>
            </a> </div>
          <div class="col-md-6 col-sm-6 col-xs-12 wow slideInRight"> <a href="">
            <div class="gglbx"> <i class="fa fa-google-plus fntsz1 pd2" aria-hidden="true"></i>Login with Google Plus </div>
            </a> </div>
        </div>
        <div class="col-md-4 col-sm-4 wow slideInRight"> </div>
      </div>
    </div>
    
    <!--===========container end here ========================-->
    
    <div class="container top_pad10 botm_pad30"> </div>
    
    <!--===========container end here ========================-->
    
    <div class="clear"></div>
    <div class="container-fluid top_pad30 botm_pad30 bgclr4 wow fadeInLeft">
      <div class="col-md-2 col-sm-3 col-xs-12">
        <div class="su_list1">
          <h3 class="bm_mar10">Corporate Information</h3>
          <ul>
            <li><a href="">About Us</a></li>
            <li><a href="">Our Investors</a></li>
            <li><a href="">Our Blog</a></li>
            <li><a href="">Our Team</a></li>
            <li><a href="">Sitemap</a></li>
          </ul>
        </div>
      </div>
      <!--===========col-md-3 end here ========================-->
      
      <div class="col-md-2 col-sm-3 col-xs-12">
        <div class="su_list1">
          <h3 class="bm_mar10">Our Services</h3>
          <ul>
            <li><a href="">Terms & Conditions</a></li>
            <li><a href="">Privecy Policy</a></li>
            <li><a href="">Fare Rules</a></li>
            <li><a href="">User Agreement</a></li>
            <li><a href="">Holiday Retail Store</a></li>
          </ul>
        </div>
      </div>
      <!--===========col-md-3 end here ========================-->
      
      <div class="col-md-2 col-sm-3 col-xs-12">
        <div class="su_list1">
          <h3 class="bm_mar10">Customer Care</h3>
          <ul>
            <li><a href="">Help & FAQs</a></li>
            <li><a href="">Privecy Policy</a></li>
            <li><a href="">Fare Rules</a></li>
            <li><a href="">User Agreement</a></li>
            <li><a href="">Holiday Retail Store</a></li>
          </ul>
        </div>
      </div>
      <!--===========col-md-3 end here ========================-->
      
      <div class="col-md-2 col-sm-3 col-xs-12">
        <div class="su_list1">
          <h3 class="bm_mar10">Why Buy With Greenindia</h3>
          <ul>
            <li><a href="">Testimonial</a></li>
            <li><a href="">Awards Won</a></li>
            <li><a href="">Greenindia in the News</a></li>
            <li><a href="">Press Releases</a></li>
            <li><a href="">Holiday Retail Store</a></li>
          </ul>
        </div>
      </div>
      <!--===========col-md-3 end here ========================-->
      
      <div class="col-md-2 col-sm-3 col-xs-12">
        <div class="su_list1">
          <h3 class="bm_mar10">Partner With Us</h3>
          <ul>
            <li><a href="">Become an Affiliate</a></li>
            <li><a href="">Become a Channel Partner</a></li>
            <li><a href="">Register Your Hotel</a></li>
            <li><a href="">Advertise With Us</a></li>
            <li><a href="">Greenindia Holiday Advisors</a></li>
            <li><a href="">Sell Holiday Packages</a></li>
            <li><a href="">Register Your Homestay</a></li>
          </ul>
        </div>
      </div>
      <!--===========col-md-3 end here ========================-->
      
      <div class="col-md-2 col-sm-3 col-xs-12">
        <div class="su_list1">
          <h3 class="bm_mar10">More</h3>
          <ul>
            <li><a href="">Travel Agents</a></li>
            <li><a href="">IDG Investee Company</a></li>
            <li><a href="">Adventure Nation</a></li>
            <li><a href="">Corporate & SMEs</a></li>
            <li><a href="">Gift Vouchers</a></li>
            <li><a href="">Foreign Exchange</a></li>
            <li><a href="">Armed Forces Personnel</a></li>
          </ul>
        </div>
      </div>
      <!--===========col-md-3 end here ========================--> 
      
    </div>
    
    <!--===========containerfluid end here ========================-->
    <div class="clear"></div>
    <div class="bgclr1 wow fadeInRight">
    <div class="container top_pad30 botm_pad30">
      <div class="col-md-6 col-sm-6">
        <div class="flleft1">
          <h6 class="whit2">We Accept</h6>
        </div>
        <div class="flleft1"> <img src="<?= base_url();?>assets/public/images/visa.png" alt="greenindia"> </div>
        <div class="flleft1"> <img src="<?= base_url();?>assets/public/images/master.png" alt="greenindia"> </div>
        <div class="flleft1"> <img src="<?= base_url();?>assets/public/images/american.png" alt="greenindia"> </div>
        <div class="flleft1"> <img src="<?= base_url();?>assets/public/images/net.png" alt="greenindia"> </div>
        <div class="flleft1"> <img src="<?= base_url();?>assets/public/images/emi.png" alt="greenindia"> </div>
        <div class="flleft1"> <img src="<?= base_url();?>assets/public/images/rupay.png" alt="greenindia"> </div>
      </div>
      <!--===========col-md-6 end here ========================-->
      <div class="col-md-6 col-sm-6">
        <div class="flleft1">
          <h6 class="whit2">Secured Sites <img src="<?= base_url();?>assets/public/images/scrd.png" alt="greenindia"> </h6>
        </div>
        <div class="flleft1">
          <h6 class="whit2">Secured Sites <img src="<?= base_url();?>assets/public/images/vrsn.png" alt="greenindia"> </h6>
        </div>
        <div class="flleft1">
          <h6 class="whit2">Our Premium Business Partner <a href="http://www.emarald.in/hotel-calicut/"><img src="<?= base_url();?>assets/public/images/emerald.png" alt="greenindia"></a> </h6>
        </div>
      </div>
    </div>
    <!--===========containerfluid end here ========================-->
    
    <div class="container botm_pad10">
      <div class="border1"></div>
      <h6 class="text-center tp_mar10 whit2">Copyrights © 2017 greenindia.com. All Rights Reserved. Designed by <a href="http://www.cybaze.com/" target="_blank"><img src="<?= base_url();?>assets/public/images/icons/newlogocybaze.png" /></a></h6>
    </div>
    </div>
  </section>
  
  <!--===========section end here ========================-->
  <div id="back-top" style="display: block;"> <a class="gototop" href="#"><span></span> </a> </div>





</footer>
<!--===========footer end here ========================--> 


<script type="text/javascript" src="<?= base_url();?>assets/public/js/jquery-2.0.3.js"></script> 

<script src="<?= base_url();?>assets/public/js/bootstrap.js"></script> 

<script type="text/javascript" src="<?= base_url();?>assets/public/js/scrolling.js"></script> 
<script type="text/javascript" src="<?= base_url();?>assets/public/js/stickynav.js"></script> 

<script src="<?= base_url();?>assets/public/js/jquery.singlePageNav.min.js"></script> 
<script src="<?= base_url();?>assets/public/js/typed.js"></script> 
<script src="<?= base_url();?>assets/public/js/wow.min.js"></script> 
<script src="<?= base_url();?>assets/public/js/custom.js"></script>

<script src="<?= base_url();?>assets/public/js/ddmenu.js"></script>


   <script src="<?php echo base_url();?>assets/public/validation/js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8">
  </script>
  <script src="<?php echo base_url();?>assets/public/validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8">
  </script>
 <script type="text/javascript" src="<?php echo base_url();?>assets/public/js/jquery.noty.packaged.min.js"></script>

<!--===========common js end ========================--> 
<script type="text/javascript">
  $(document).ready(function(){
 $('#otp_form_reg').hide();
    $('.btn_register').click(function(e){
      e.preventDefault();
        var st = $("#register_form").validationEngine("validate");
        if(st == true)
        {
          
          var datas = $('#register_form').serializeArray();
         
           $('.body_blur').show();
          $.post('<?= base_url();?>register/new_customer', datas, function(data){
             $('.body_blur').hide();
            if(data.status)
            {
              var data = data.data;
              $('#register_form :input').attr('readonly','readonly');
              $('#otp_form_reg').show('slow');
             $('#otp_form_reg').find('#email').val(data.email);
             $('#otp_form_reg').find('#mobile').val(data.phone);
               noty({text:"A verification code has been sent to your mobile and email", type: 'success',layout: 'center'});
                $('#otp_model').modal({backdrop: 'static', keyboard: false });
            }else{
                 noty({text:data.reason, type: 'error',layout: 'top', timeout: 2000});
                
            }
          },'json');

        }
      

    });

$('.submit_otp').click(function(e){
      e.preventDefault();
        var otp_entered = $("#otp_form_reg").find('#reg_otp').val();
        if(otp_entered != '')
        {

            var datas = $('#otp_form_reg').serializeArray();
           $('.body_blur').show();
          $.post('<?= base_url();?>register/validate_otp', datas, function(data){
             $('.body_blur').hide();
            if(data.status)
            {
              noty({text:"Your registration completed Successfully Please login", type: 'success',layout: 'center'});
               window.location = '<?= base_url();?>home';
            }else{
                 noty({text:data.reason, type: 'error',layout: 'top', timeout: 2000});
                
            }
          },'json');

        }
      

    });
$('.continue_login').click(function(e){
      e.preventDefault();
        var st = $("#login_form").validationEngine("validate");
        if(st == true)
        {

            var datas = $('#login_form').serializeArray();
           $('.body_blur').show();
          $.post('<?= base_url();?>user/login/login_process', datas, function(data){
             $('.body_blur').hide();
            if(data.status)
            {
              noty({text:"Login Successfully", type: 'success',layout: 'center'});
              window.location = '<?= base_url();?>home';
            }else{
                 noty({text:data.reason, type: 'error',layout: 'top', timeout: 2000});
            }
          },'json');

        }
      

    });

  });
</script>
<script type="text/javascript">
      $(document).ready(function(){
        $(".forgot" ).hide();
        $( ".triggerforgot" ).click(function() {
            $( ".forgot" ).toggle( "slow");
        });
        $('.sub_forgot').click(function(e){
          e.preventDefault();
          var cur = $(this);
          var uname = cur.parent().parent().parent().find('.forgot_uname').val();
          
          $.post('<?php echo base_url();?>admin/login/forgot_password', {uname:uname}, function(data){
            if(data.status){
              noty({text: 'password sent to your email', type: 'success', timeout:1000});
            } else{
              noty({text: data.reason, type: 'error', timeout:2000});
            }

          },'json');
        });
      });
       $(document).ready(function(){
        $('.input_price').on('input', function(){
          var current_rs = $(this).parent().parent().find('.current_rs').text();
          var current_rs = isNaN(current_rs) ? 0 : current_rs;
          var entered_rs = isNaN(parseFloat($(this).val())) ? 0 : parseFloat($(this).val());
            get_wallet_billing();
          if(entered_rs > current_rs)
          {
            noty({text:"Not enough Money in this wallet", type: 'error',layout: 'center', timeout: 2000});
          }else{
          

          }
          
        

        });


       

      });
       function get_wallet_billing()
       {
        var sum = 0;
          $('.input_price').each(function(){
            var cur = $(this);
            var money_wallet = parseFloat($(this).val());
            money_wallet = isNaN(money_wallet) ? 0 : money_wallet;
            sum = sum + money_wallet;
          });
          $('#sum_of_billing').val(sum);
          
       }
    </script>
    <script type="text/javascript">
      $(document).ready(function(){
         $('#submit_billing').click(function(e){
          e.preventDefault();

          var st = $("#billing_form").validationEngine("validate");

        if(st == true)
        {
          var datas = $('#billing_form').serializeArray();
          $.post('<?= base_url();?>user/purchase/give_notification', datas, function(data){
            if(data.status)
            {
              noty({text:"under verification", type: 'success', layout: 'top', timeout: 2000});
              $('#billing').modal('hide');
            }else{
              noty({text:data.reason, type: 'error', layout: 'top', timeout: 2000});
            }
          },'json');
          
        }else{
        //   noty({text:"Not enough Money in this wallet", type: 'error',layout: 'center', timeout: 2000});
        }
        });
      });
    </script>
    <script type="text/javascript">
  $(function() {
  $('#billing_form').on('keydown', '.input_price', function(e){-1!==$.inArray(e.keyCode,[46,8,9,27,13,110,190])||/65|67|86|88/.test(e.keyCode)&&(!0===e.ctrlKey||!0===e.metaKey)||35<=e.keyCode&&40>=e.keyCode||(e.shiftKey||48>e.keyCode||57<e.keyCode)&&(96>e.keyCode||105<e.keyCode)&&e.preventDefault()});
});
</script>