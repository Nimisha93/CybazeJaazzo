<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta mame="description" content=" " />
<META content="ALL" name="ROBOTS"/>
<META content="FOLLOW" name="ROBOTS"/>
<META content="" name="copyright"/>
<meta name="distribution" content="Global" />
<title>Greenindia</title>
<link rel="shortcut icon" href="<?= base_url();?>assets/public/favicon/favicon.png">
<?= $default_assets;?>

 <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/public/css/slick.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/public/css/slick-theme.css">

<link type="text/css" rel="stylesheet" href="<?= base_url();?>assets/public/css/deal/thumbnailslider.css" />
  
  
   
<style type="text/css">

.row{margin:0;}
@media (max-width:767px){
  
  .goToTop {
  position: static;
  top: 0;
  left: 0;
  height: 210px;
  z-index: 10;
}
.row{margin:0;}
}


</style>





    
<style>
.row{margin-left:0; margin-right:0;}

.goToTop{height:50px;position:fixed;background-color:#fff;border-bottom:1px solid #000}
@media (max-width:1000px){
  
.goToTop{height:auto;position:relative;background-color:#fff;}
  
  
}

</style>
</head>

<body>

<!--===========header end here ========================-->


  <?= $header;?>
   
   

   
  


<div class="clear"></div>

<!--===========main end here ========================-->

 
  
  <!--===========section end here ========================-->
  
 
    <!--===========section end here ========================-->
  <div class="clear"></div>
  
<!-- Begin Body -->



  <section class="bgclr6 top_pad50 botm_pad50">
    <div id="photos" class=""></div>
     
    
    <div class="clear" ></div>
    
   
    <div class="container ">
    <div class="bgclr3 border3">
    <div class="su_box90_marauoto">
  
    
    
    <div class="col-md-5 col-sm-5"> 
                              
                            
                              <div class="row">
                              <div class="inneroffr">Save <span class="rupee">RS</span> 765</div>
                              <div id="slider1_container" class="innr_sldr">
 
        <!-- Loading Screen -->
        <div u="loading" style="position: absolute; top: 0px; left: 0px;">
            <div class="innrsl">
            </div>
            <div style="position: absolute; display: block; background: url(../img/loading.gif) no-repeat center center;
                top: 0px; left: 0px;width: 100%;height:100%;">
            </div>
        </div>

        <!-- Slides Container -->
        <div u="slides" style="cursor: move; position: absolute; left: 0px; top: 0px; width: 400px; height: 450px; overflow: hidden;">
            
             <div>
                <img u="image" src="<?= base_url();?>assets/public/images/mydeals/mobile/1.jpg" />
                <img u="thumb" src="<?= base_url();?>assets/public/images/mydeals/mobile/1.jpg" />
            </div>
            <div>
                <img u="image" src="<?= base_url();?>assets/public/images/mydeals/mobile/2.jpg" />
                <img u="thumb" src="<?= base_url();?>assets/public/images/mydeals/mobile/2.jpg" />
            </div>
            <div>
                <img u="image" src="<?= base_url();?>assets/public/images/mydeals/mobile/3.jpg" />
                <img u="thumb" src="<?= base_url();?>assets/public/images/mydeals/mobile/3.jpg" />
            </div>
            <div>
                <img u="image" src="<?= base_url();?>assets/public/images/mydeals/mobile/4.jpg" />
                <img u="thumb" src="<?= base_url();?>assets/public/images/mydeals/mobile/4.jpg" />
            </div>
           
        </div>
        
        <!-- Arrow Navigator Skin Begin -->
       
        <!-- Arrow Left -->
        <span u="arrowleft" class="jssora05l" style="width: 40px; height: 40px; top: 158px; left: 8px;">
        </span>
        <!-- Arrow Right -->
        <span u="arrowright" class="jssora05r" style="width: 40px; height: 40px; top: 158px; right: 8px">
        </span>
        <!-- Arrow Navigator Skin End -->
        
        <!-- Thumbnail Navigator Skin Begin -->
        <div u="thumbnavigator" class="jssort01" style="position: absolute; width: 400px; height: 100px; left:0px; bottom: 0px;">
            <!-- Thumbnail Item Skin Begin -->
           
            <div u="slides" style="cursor: move;">
                <div u="prototype" class="p" style="position: absolute; width: 72px; height: 72px; top: 0; left: 0;">
                    <div class=w><div u="thumbnailtemplate" style=" width: 100%; height: 100%; border: none;position:absolute; top: 0; left: 0;"></div></div>
                    <div class=c>
                    </div>
                </div>
            </div>
            
           
            <!-- Thumbnail Item Skin End -->
        </div>
        <!-- Thumbnail Navigator Skin End -->
        <!-- Trigger -->
        <script>
            jssor_slider1_starter('slider1_container');
        </script>
    </div>
                              
                          </div>

                            
                              
                              
                






  
                    
                    
                            </div>
                            
                            
                            
                            
                            <div class="col-md-7 col-sm-7">
                           
                            <div class="brndname">Sansui 150 L Direct Cool Single Door Refrigerator</div>
                           
                            <div class="companylogo"><img src="<?= base_url();?>assets/public/images/home/bismi.png"></div>
                            <div class="companyname">Deal with Bismi</div>
                            <div class="clear"></div>
                            <div class="line2 tp_mar20"></div>
                             <div class="row">
                            
  
       </div>
       <div class="clear"></div>
       
                            <div class="row">
                            
                            
                              
                              <div class="col-md-12">
         
                             
                            <table class="brnd_spcifctn tp_mar10">
        <thead>
      <tr>
        <th class="spcfcn">Specification</th>
       
      </tr>
    </thead>
    
    <tbody>
      <tr>
        <td class="spci">Sales Package</td>
        <td>Handset, Adapter, Earphone, User Manual</td>
      </tr>
      <tr>
        <td class="spci">Model Number</td>
        <td>J710FZDGINS</td>
      </tr>
      <tr>
        <td class="spci">Model Name</td>
        <td>Galaxy On8</td>
      </tr>
    </tbody>
  </table>
                            
                         </div>        
                              <div class="clear"></div>
                              
                              <a class="morspcfcn" data-scroll data-options='{ "easing": "easeInQuad" }' href="#more">more...</a>
                             
                              
                         <div class="line1 tp_mar20"></div>     
                              <div class="col-md-12">
                            
                            <div class="ratebox">
                            <table>
                            <tr>
                            <td class="brand_rate"> MRP</td>
                            <td class="brand_rate_none"> <span class="rupee">RS</span>3950 </td>
                            </tr>
                            
                            <tr>
                            <td class="brand_rate"> Company Rate</td>
                            <td class="brand_rate_none"> <span class="rupee">RS</span>3450 </td>
                            </tr>
                            
                            <tr>
                            <td class="brand_rate"> Our Deal</td>
                            <td class="brand_rate_actual"> <span class="rupee">RS</span>2550 </td>
                            </tr>
                            
                            </table>

                              </div></div>
                              
                              </div>
                              <div class="brand_offer">20% Off</div>
                              <div class="brand_offer_dealbtn"><a href=""> Get this Deal </a>
                               </div>
                            </div>
                            
         <div class="clear"></div>
         
         
                      <div id="more" class="border3 tp_mar50" >
  <div class="col-md-12">
         
                              <h2 class="text-left"> Full Specification</h2>
                              <div class="line2 bm_mar20"></div>
                            <table class="brnd_spcifctn_full tp_mar10">
        <thead>
      <tr>
      
      </tr>
    </thead>
    
    <tbody>
       <tr>
        <td class="spci"> Sales Package</td>
        <td>Handset, Adapter, Earphone, User Manual</td>
      </tr>
      <tr>
        <td class="spci">Model Number</td>
        <td>J710FZDGINS</td>
      </tr>
      <tr>
        <td class="spci">Model Name</td>
        <td>Galaxy On8</td>
      </tr>
          <tr>
        <td class="spci">Sales Package</td>
        <td>Handset, Adapter, Earphone, User Manual</td>
      </tr>
      <tr>
        <td class="spci">Model Number</td>
        <td>J710FZDGINS</td>
      </tr>
      <tr>
        <td class="spci">Model Name</td>
        <td>Galaxy On8</td>
      </tr>
          <tr>
        <td class="spci">Sales Package</td>
        <td>Handset, Adapter, Earphone, User Manual</td>
      </tr>
      <tr>
       <td class="spci">Model Number</td>
        <td>J710FZDGINS</td>
      </tr>
      <tr>
        <td class="spci">Model Name</td>
        <td>Galaxy On8</td>
      </tr>
      
    </tbody>
  </table>
                            
                         </div>
  
  </div>        
                            
  </div> 
  

  
 
  
  </div ></div>
  
  
               
  
  
    
    <!--===========col-md-3 end here ========================--> 
    
  </section>

<!--===========header end here ========================-->

<div class="clear"></div>

<section class="bgclr6">
<div class="container">
<div class="hdln1">
        <h4 style="background-color:#cccccc">Related Products</h4>
        </div>

<section class="regular slider">
   
    <div>
      
    <div class="deal"> <img src="<?= base_url();?>assets/public/images/mydeals/mobile.jpg">
        <div class="ofrzon2">Get <span class="fntsz5">30%</span> Off
        <div class="tp_mar10">/2 Days left</div>
        </div>
        <a href="deal-inner.php">
        <div class="redmr2">Get this deal</div>
        </a>
        <div class="su_box100 dealbg1">
        <h4><img src="<?= base_url();?>assets/public/images/home/bismi.png" class="logoleft">Deal with Bismi  </h4>
        </div>
        
        <h3>Sansui 150 L Direct Cool Single Door Refrigerator  </h3>
        <div class="clear"></div>
        <div class="col-xs-12">
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="oldrate1"> 120 </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="offferrate1"> 69 </div>
          </div>
        </div>
        
        <div class="clear"></div>
      </div>
    
    </div>
   
    <div>
      <div class="deal"> <img src="<?= base_url();?>assets/public/images/mydeals/mobile.jpg">
        <div class="ofrzon2">Get <span class="fntsz5">30%</span> Off
        <div class="tp_mar10">/2 Days left</div>
        </div>
        <a href="deal-inner.php">
        <div class="redmr2">Get this deal</div>
        </a>
        <div class="su_box100 dealbg1">
        <h4><img src="<?= base_url();?>assets/public/images/home/bismi.png" class="logoleft">Deal with Bismi  </h4>
        </div>
        
        <h3>Sansui 150 L Direct Cool Single Door Refrigerator  </h3>
        <div class="clear"></div>
        <div class="col-xs-12">
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="oldrate1"> 120 </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="offferrate1"> 69 </div>
          </div>
        </div>
        
        <div class="clear"></div>
      </div>
    </div>
    <div>
      <div class="deal"> <img src="<?= base_url();?>assets/public/images/mydeals/mobile.jpg">
        <div class="ofrzon2">Get <span class="fntsz5">30%</span> Off
        <div class="tp_mar10">/2 Days left</div>
        </div>
        <a href="deal-inner.php">
        <div class="redmr2">Get this deal</div>
        </a>
        <div class="su_box100 dealbg1">
        <h4><img src="<?= base_url();?>assets/public/images/home/bismi.png" class="logoleft">Deal with Bismi  </h4>
        </div>
        
        <h3>Sansui 150 L Direct Cool Single Door Refrigerator  </h3>
        <div class="clear"></div>
        <div class="col-xs-12">
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="oldrate1"> 120 </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="offferrate1"> 69 </div>
          </div>
        </div>
        
        <div class="clear"></div>
      </div>
    </div>
    <div>
      <div class="deal"> <img src="<?= base_url();?>assets/public/images/mydeals/mobile.jpg">
        <div class="ofrzon2">Get <span class="fntsz5">30%</span> Off
        <div class="tp_mar10">/2 Days left</div>
        </div>
        <a href="deal-inner.php">
        <div class="redmr2">Get this deal</div>
        </a>
        <div class="su_box100 dealbg1">
        <h4><img src="<?= base_url();?>assets/public/images/home/bismi.png" class="logoleft">Deal with Bismi  </h4>
        </div>
        
        <h3>Sansui 150 L Direct Cool Single Door Refrigerator  </h3>
        <div class="clear"></div>
        <div class="col-xs-12">
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="oldrate1"> 120 </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="offferrate1"> 69 </div>
          </div>
        </div>
        
        <div class="clear"></div>
      </div>
    </div>
    <div>
      <div class="deal"> <img src="<?= base_url();?>assets/public/images/mydeals/mobile.jpg">
        <div class="ofrzon2">Get <span class="fntsz5">30%</span> Off
        <div class="tp_mar10">/2 Days left</div>
        </div>
        <a href="deal-inner.php">
        <div class="redmr2">Get this deal</div>
        </a>
        <div class="su_box100 dealbg1">
        <h4><img src="<?= base_url();?>assets/public/images/home/bismi.png" class="logoleft">Deal with Bismi  </h4>
        </div>
        
        <h3>Sansui 150 L Direct Cool Single Door Refrigerator  </h3>
        <div class="clear"></div>
        <div class="col-xs-12">
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="oldrate1"> 120 </div>
          </div>
          <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="offferrate1"> 69 </div>
          </div>
        </div>
        
        <div class="clear"></div>
      </div>
    </div>
    
  </section>

</div>

</section>



<div id="back-top" style="display: block;"> <a class="gototop" href="#"><span></span> </a> </div>
<?php echo $footer; ?>
<!-- <script src="<?= base_url();?>assets/public/js/cbpHorizontalMenu.min.js"></script>
<script>
      $(function() {
        cbpHorizontalMenu.init();
      });
    </script> -->

 <script type="text/javascript" src="<?= base_url();?>assets/public/js/htl-inner/jssor.js"></script>
    <script type="text/javascript" src="<?= base_url();?>assets/public/js/htl-inner/jssor.slider.js"></script>
     <script type="text/javascript" src="<?= base_url();?>assets/public/js/htl-inner/slidthumbnail.js"></script> 
<!--=======================================slider right==============================================--> 

<script src="<?= base_url();?>assets/public/js/slick.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    $(document).on('ready', function() {
    /*  $(".regular").slick({
        dots: true,
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 4,
      });*/
      $(".center").slick({
        dots: true,
        infinite: true,
        centerMode: true,
        slidesToShow: 3,
        slidesToScroll: 3
      });
      $(".variable").slick({
        dots: true,
        infinite: true,
        variableWidth: true,
    slidesToShow: 1,  
        slidesToScroll: 1,
      });
    });
  

  </script>
  
  <script>
  
  $(document).on('ready', function() {
 $('.regular').slick({
  dots: true,
  loop: true,
  speed: 300,
  slidesToShow: 5,
  slidesToScroll: 4,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 800,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 580,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
 });

</script>


<script>
  
  $(document).on('ready', function() {
 $('.regular2').slick({
  dots: true,
  loop: true,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 800,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 580,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
 });

</script>


<script type="text/javascript">
    // <![CDATA[
    $(document).ready(function() {
        $(".gototop").click(function() {
            $("html, body").animate({"scrollTop": "0px"});
        });
    });
</script> 

</body>
</html>